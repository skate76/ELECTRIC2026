from copy import deepcopy
from math import floor
from scipy.optimize import linprog


def cost_per_use(appliance, rate):
    return round(
        (float(appliance.get("watts", 0)) / 1000.0)
        * float(appliance.get("hours_per_use", 1))
        * float(rate)
        * int(appliance.get("quantity", 1)),
        6
    )


def _billing_days(user):
    try:
        return max(1, int(user.get("days", 30)))
    except (TypeError, ValueError):
        return 30


def _max_remaining_uses(app, days=None):
    """Return how many more planned/actual uses can fit in the billing period.

    IMPORTANT:
    - desired_uses is the user's current goal.
    - billing period days is the TRUE hard maximum.
    - For Ask for More Usage / Transfer, pass days so appliances can grow past their original desired_uses.
    """
    consumed = max(0, int(app.get("consumed_uses", 0)))

    if days is not None:
        return max(0, int(days) - consumed)

    desired = max(0, int(app.get("desired_uses", 0)))
    return max(0, desired - consumed)


def ensure_defaults(user):
    days = _billing_days(user)
    for app in user.get("appliances", []):
        if int(app.get("desired_uses", 0)) <= 0:
            app["desired_uses"] = int(app.get("default_desired_uses", 1))

        # Uses wanted is day-based, so it must never exceed the billing period.
        app["desired_uses"] = min(max(0, int(app.get("desired_uses", 1))), days)
        app.setdefault("allocated_uses", None)

        if app.get("allocated_uses") is not None:
            # Saved/current allocation may be higher than the original desired_uses
            # after Ask for More Usage or Transfer. Only billing days is the hard cap.
            app["allocated_uses"] = min(
                max(0, int(app.get("allocated_uses", 0))),
                _max_remaining_uses(app, days)
            )


def optimize_usage(user, use_allocated_if_present=True):
    budget = float(user.get("budget", 0))
    rate = float(user.get("rate", 45.46))
    appliances = user.get("appliances", [])

    if not appliances:
        return {"status": "Failed", "error": "No appliances added."}
    if budget <= 0:
        return {"status": "Failed", "error": "Budget must be greater than zero."}

    ensure_defaults(user)

    already_spent = sum(
        int(app.get("consumed_uses", 0)) * cost_per_use(app, rate)
        for app in appliances
    )
    remaining_budget = budget - already_spent

    overrun = remaining_budget < 0
    overspend = round(abs(remaining_budget), 2) if overrun else 0.0
    effective_budget = max(0.0, remaining_budget)

    plan = []
    for idx, app in enumerate(appliances):
        cpu = cost_per_use(app, rate)
        desired = max(0, int(app.get("desired_uses", 0)))
        consumed = max(0, int(app.get("consumed_uses", 0)))
        allocated_saved = app.get("allocated_uses")

        remaining_uses = max(0, desired - consumed)

        if use_allocated_if_present and allocated_saved is not None:
            # Saved allocations are still capped by the remaining uses wanted.
            target_uses = min(max(0, int(allocated_saved)), remaining_uses)
        else:
            target_uses = remaining_uses

        priority = max(1, int(app.get("priority", 5)))
        plan.append({
            "index": idx,
            "name": app["name"],
            "priority": priority,
            "unit_label": app.get("unit_label", "use"),
            "desired_uses": desired,
            "consumed_uses": consumed,
            "remaining_uses": remaining_uses,
            "allowed_uses": 0,
            "target_uses": target_uses,
            "cost_per_use_raw": cpu,
            "cost_per_use": round(cpu, 2),
        })

    n = len(plan)

    c = [-item["priority"] for item in plan] ##This is the objective function
    A_ub = [[item["cost_per_use_raw"] for item in plan]]     ##Budget Constraints
    b_ub = [effective_budget]                                  ##Budget Constraints
    bounds = [(0, item["target_uses"]) for item in plan]    ##Minimum and max for each decision variable

    result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")

    if result.status != 0:
        return {"status": "Failed", "error": "Optimization could not find a solution."}

    allocations = list(result.x)
    int_allocs = [int(floor(a)) for a in allocations]

    remaining = effective_budget - sum(
        int_allocs[i] * plan[i]["cost_per_use_raw"] for i in range(n)
    )

    capped = [False] * n
    safety = 0
    #Strict priority order: highest priority gets extra uses first
    priority_order = sorted(range(n), key=lambda i: -plan[i]["priority"])

    while remaining > 1e-6 and safety < 1000:
        safety += 1
        changed = False

        for i in priority_order:
            if capped[i]:
                continue
            cpu = plan[i]["cost_per_use_raw"]
            if cpu <= 0:
                capped[i] = True
                continue
            if int_allocs[i] >= plan[i]["target_uses"]:
                capped[i] = True
                continue
            if remaining + 1e-9 >= cpu:
                int_allocs[i] += 1
                remaining -= cpu
                changed = True
                if int_allocs[i] >= plan[i]["target_uses"]:
                    capped[i] = True

        if not changed:
            break

    total_allocated_cost = 0.0
    total_priority = sum(item["priority"] for item in plan) or 1

    for i, item in enumerate(plan):
        item["allowed_uses"] = int_allocs[i]
        item_cost = int_allocs[i] * item["cost_per_use_raw"]
        total_allocated_cost += item_cost
        item["cost"] = round(item_cost, 2)
        item["priority_share"] = round((item["priority"] / total_priority) * 100, 1)
        item.pop("cost_per_use_raw", None)

    total_cost = round(already_spent + total_allocated_cost, 2)

    return {
        "status": "Success",
        "optimized_plan": sorted(plan, key=lambda x: x["index"]),
        "total_cost": total_cost,
        "already_spent": round(already_spent, 2),
        "remaining_budget_after_plan": round(max(0, effective_budget - total_allocated_cost), 2),
        "budget_remaining": round(max(0, effective_budget - total_allocated_cost), 2),
        "overrun": overrun,
        "overspend": overspend,
    }


def save_current_allocation(user, optimized=None):
    if optimized is None:
        optimized = optimize_usage(user, use_allocated_if_present=False)
    if optimized.get("status") != "Success":
        return optimized
    for item in optimized["optimized_plan"]:
        idx = int(item["index"])
        if 0 <= idx < len(user.get("appliances", [])):
            user["appliances"][idx]["allocated_uses"] = int(item["allowed_uses"])
    return optimize_usage(user, use_allocated_if_present=True)


def build_usage_summary(optimized):
    if not optimized or optimized.get("status") not in ("Success",):
        return []
    rows = []
    for item in optimized["optimized_plan"]:
        desired = int(item.get("desired_uses", 0))
        allowed = int(item.get("allowed_uses", 0))
        consumed = int(item.get("consumed_uses", 0))
        remaining = int(item.get("remaining_uses", desired))
        pct = 100 if remaining <= 0 else round((allowed / remaining) * 100)
        rows.append({
            "name": item["name"],
            "allowed_uses": allowed,
            "desired_uses": desired,
            "consumed_uses": consumed,
            "remaining_uses": remaining,
            "unit_label": item["unit_label"],
            "percent": min(100, max(0, pct)),
            "cost": item["cost"],
        })
    return rows


def _find_by_name(user, name):
    for app in user.get("appliances", []):
        if app["name"] == name:
            return app
    return None


def _find_by_index(user, index):
    try:
        index = int(index)
    except Exception:
        return None
    apps = user.get("appliances", [])
    return apps[index] if 0 <= index < len(apps) else None


def _current_uses(app, days=None):
    consumed = max(0, int(app.get("consumed_uses", 0)))

    if app.get("allocated_uses") is not None:
        raw = int(app.get("allocated_uses", 0))
    else:
        raw = int(app.get("desired_uses", 0))

    if days is not None:
        max_allowed = max(0, int(days) - consumed)
        return max(0, min(raw, max_allowed))

    return max(0, raw)

def _set_current_uses(app, value, days=None):
    consumed = max(0, int(app.get("consumed_uses", 0)))

    if days is not None:
        max_allowed = max(0, int(days) - consumed)
        app["allocated_uses"] = min(max(0, int(value)), max_allowed)
    else:
        app["allocated_uses"] = max(0, int(value))

def _increment_current_uses(app, amount, days=None):
    current = _current_uses(app, days)
    _set_current_uses(app, current + int(amount), days)

def allocate_remaining_budget(user, selected_indexes=None):
    optimized = optimize_usage(user, use_allocated_if_present=True)
    if optimized.get("status") != "Success":
        return False, optimized.get("error", "Optimization failed."), None

    remaining = float(optimized.get("budget_remaining", 0))
    if remaining <= 0:
        return False, "There is no remaining budget to allocate.", optimized

    selected_indexes = selected_indexes or [str(i) for i in range(len(user.get("appliances", [])))]
    selected = []
    for idx in selected_indexes:
        app = _find_by_index(user, idx)
        if app:
            selected.append((int(idx), app))

    if not selected:
        return False, "Select at least one appliance to receive the remaining budget.", optimized

    days = _billing_days(user)
    selected.sort(key=lambda pair: (-int(pair[1].get("priority", 5)), cost_per_use(pair[1], user.get("rate", 45.46))))

    added = 0
    safety = 0
    while safety < 1000:
        safety += 1
        changed = False
        for _, app in selected:
            cpu = cost_per_use(app, user.get("rate", 45.46))
            if cpu > 0 and remaining + 1e-9 >= cpu:
                current_alloc = _current_uses(app, days)
                consumed = max(0, int(app.get("consumed_uses", 0)))

                # True maximum is the billing period, not the original Uses Wanted.
                max_alloc = max(0, days - consumed)
                if current_alloc >= max_alloc:
                    continue

                _set_current_uses(app, current_alloc + 1, days)

                # Expand Uses Wanted so the dashboard and saved plan reflect the added allocation.
                app["desired_uses"] = min(
                    days,
                    max(int(app.get("desired_uses", 0)), int(app.get("allocated_uses", 0)) + consumed)
                )

                remaining -= cpu
                added += 1
                changed = True
        if not changed:
            break

    new_plan = optimize_usage(user, use_allocated_if_present=True)
    if added == 0:
        all_capped = all(
            _current_uses(app, days) >= max(0, days - max(0, int(app.get("consumed_uses", 0))))
            for _, app in selected
        )
        if all_capped:
            msg = "All selected appliances have reached the maximum usage for this billing period."
        else:
            msg = "The remaining budget is too small to pay for one more selected appliance use."
        return False, msg, new_plan
    return True, f"Remaining budget allocated into {added} extra use(s).", new_plan


def _reducible_apps(user, excluded_names=None):
    if excluded_names is None:
        excluded_names = []
    apps = []
    for app in user.get("appliances", []):
        if app["name"] in excluded_names:
            continue
        if _current_uses(app) > 0:
            apps.append(app)
    return apps


def _build_reduction(app, amount):
    current = _current_uses(app)
    amount = min(current, max(0, int(amount)))
    return {
        "appliance": app["name"],
        "reduced_by": amount,
        "unit_label": app.get("unit_label", "use"),
        "current_allocation": current,
        "remaining_after": max(0, current - amount),
    }


def _reduce_for_cost(user, extra_cost, excluded_names=None, mode="balanced"):
    if excluded_names is None:
        excluded_names = []
    apps = _reducible_apps(user, excluded_names)

    if mode == "concentrated":
        apps = sorted(apps, key=lambda a: (int(a.get("priority", 5)), -_current_uses(a)))
    else:
        apps = sorted(apps, key=lambda a: (int(a.get("priority", 5)), a["name"]))

    reductions = []
    remaining = float(extra_cost)

    while remaining > 0 and apps:
        made_change = False
        for app in list(apps):
            if _current_uses(app) <= 0:
                continue
            cpu = cost_per_use(app, user.get("rate", 45.46))
            if cpu <= 0:
                continue
            found = next((r for r in reductions if r["appliance"] == app["name"]), None)
            if found:
                found["reduced_by"] += 1
                found["remaining_after"] = max(0, found["current_allocation"] - found["reduced_by"])
            else:
                reductions.append(_build_reduction(app, 1))
            _set_current_uses(app, _current_uses(app) - 1)
            remaining -= cpu
            made_change = True
            if remaining <= 0 or mode == "concentrated":
                break
        apps = [a for a in apps if _current_uses(a) > 0]
        if not made_change:
            break

    return reductions, remaining <= 0


def _summarize(reductions):
    if not reductions:
        return "No reduction needed."
    return ", ".join(
        f"{r['appliance']} by {r['reduced_by']} {r['unit_label']}{'' if r['reduced_by'] == 1 else 's'}"
        for r in reductions
    )


def generate_preference_options(user, preferred_appliance, requested_extra):
    target = _find_by_name(user, str(preferred_appliance).strip())

    try:
        requested_extra = int(requested_extra)
    except Exception:
        requested_extra = 0

    if not target:
        return {"success": False, "error": "Preferred appliance not found."}

    if requested_extra <= 0:
        return {"success": False, "error": "Extra uses must be greater than zero."}

    days = _billing_days(user)
    current = _current_uses(target, days)
    consumed = max(0, int(target.get("consumed_uses", 0)))

    # ONLY billing period is the true maximum
    headroom = max(0, days - consumed - current)

    unit = target.get("unit_label", "use")

    if headroom <= 0:
        return {
            "success": False,
            "error": f"{target['name']} has reached the maximum usage for this billing period ({days} days)."
        }

    if requested_extra > headroom:
        return {
            "success": False,
            "error": f"Only {headroom} more {unit}{'' if headroom == 1 else 's'} can be added to {target['name']} this billing period."
        }

    extra_cost = cost_per_use(target, user.get("rate", 45.46)) * requested_extra

    options = []
    styles = [
        ("Balanced", "balanced", "Spreads reductions across appliances so the change feels less harsh."),
        ("Priority-protecting", "priority", "Reduces lower-priority appliances first."),
        ("Concentrated", "concentrated", "Reduces one lower-priority appliance as much as possible first."),
    ]

    for oid, (style, mode, subtitle) in enumerate(styles):
        clone = deepcopy(user)
        clone_target = _find_by_name(clone, target["name"])

        if clone_target:
            _increment_current_uses(clone_target, requested_extra, days)

        reductions, ok = _reduce_for_cost(
            clone,
            extra_cost,
            excluded_names=[target["name"]],
            mode=mode
        )

        if ok:
            fingerprint = tuple(sorted((r["appliance"], r["reduced_by"]) for r in reductions))

            if any(
                tuple(sorted((r["appliance"], r["reduced_by"]) for r in opt["reductions"])) == fingerprint
                for opt in options
            ):
                continue

            options.append({
                "id": oid,
                "kind": "preference",
                "preferred_appliance": target["name"],
                "preferred_extra": requested_extra,
                "style": style,
                "title": f"Add {requested_extra} more {unit}(s) to {target['name']}",
                "subtitle": subtitle,
                "reductions": reductions,
                "reduction_summary": _summarize(reductions),
            })

    return {
        "success": bool(options),
        "options": options,
        "error": None if options else "Not enough reducible usage to support that increase."
    }

def generate_overuse_options(user, appliance, extra_uses):
    target = _find_by_name(user, str(appliance).strip())
    try:
        extra_uses = int(extra_uses)
    except Exception:
        extra_uses = 0

    if not target:
        return {"success": False, "error": "Appliance not found."}
    if extra_uses <= 0:
        return {"success": False, "error": "Extra uses must be greater than zero."}

    days = _billing_days(user)
    current = _current_uses(target, days)
    consumed = max(0, int(target.get("consumed_uses", 0)))
    headroom = max(0, days - consumed - current)
    unit = target.get("unit_label", "use")

    if headroom <= 0:
        return {"success": False, "error": f"{target['name']} has reached the maximum usage for this billing period ({days} days)."}
    if extra_uses > headroom:
        return {"success": False, "error": f"Only {headroom} more {unit}{'' if headroom == 1 else 's'} can be added to {target['name']} this billing period."}

    extra_cost = cost_per_use(target, user.get("rate", 45.46)) * extra_uses
    clone = deepcopy(user)
    clone_target = _find_by_name(clone, target["name"])
    if clone_target:
        _increment_current_uses(clone_target, extra_uses, days)

    reductions, ok = _reduce_for_cost(clone, extra_cost, excluded_names=[target["name"]], mode="balanced")
    if not ok:
        return {"success": False, "error": "Not enough reducible usage to offset this overuse."}

    return {
        "success": True,
        "options": [{
            "id": 0,
            "kind": "overuse",
            "appliance": target["name"],
            "extra_uses": extra_uses,
            "style": "Correction",
            "title": f"Offset {extra_uses} extra {target.get('unit_label', 'use')}(s) of {target['name']}",
            "subtitle": "This reduces other planned usage to cover the extra usage.",
            "reductions": reductions,
            "reduction_summary": _summarize(reductions)
        }]
    }


def generate_transfer_options(user, from_appliances, released_uses_list, to_appliances):
    """Generate options to move allocation from source appliances to target appliances.

    The target can receive more usage even if it already reached its original
    desired_uses. The only hard cap is the billing period days.
    """
    if isinstance(from_appliances, str):
        from_appliances = [from_appliances]
    if isinstance(to_appliances, str):
        to_appliances = [to_appliances]
    if isinstance(released_uses_list, (int, float)):
        released_uses_list = [int(released_uses_list)]

    rate = user.get("rate", 45.46)
    days = _billing_days(user)

    sources = []
    for name, uses in zip(from_appliances, released_uses_list):
        app = _find_by_name(user, str(name).strip())
        try:
            uses = int(uses)
        except Exception:
            uses = 0
        if not app:
            return {"success": False, "error": f"Source appliance '{name}' not found."}
        if uses <= 0:
            return {"success": False, "error": f"Released uses for '{name}' must be > 0."}

        current = _current_uses(app, days)
        if uses > current:
            return {"success": False, "error": f"Can only release up to {current} {app.get('unit_label','use')}(s) from {name}."}
        sources.append((app, uses))

    source_names = [s[0]["name"] for s in sources]
    targets = []
    for name in to_appliances:
        app = _find_by_name(user, str(name).strip())
        if not app:
            return {"success": False, "error": f"Target appliance '{name}' not found."}
        if app["name"] in source_names:
            return {"success": False, "error": f"'{name}' cannot be both source and target."}

        current_alloc = _current_uses(app, days)
        consumed = max(0, int(app.get("consumed_uses", 0)))
        headroom = max(0, days - consumed - current_alloc)

        if headroom <= 0:
            return {
                "success": False,
                "error": f"'{name}' has reached the maximum usage for this billing period ({days} days)."
            }
        targets.append(app)

    if not sources or not targets:
        return {"success": False, "error": "Need at least one source and one target."}

    total_freed = sum(uses * cost_per_use(app, rate) for app, uses in sources)
    per_target_budget = total_freed / len(targets)

    target_additions = []
    for app in targets:
        cpu = cost_per_use(app, rate)
        raw_possible = int(floor(per_target_budget / cpu)) if cpu > 0 else 0
        current_alloc = _current_uses(app, days)
        consumed = max(0, int(app.get("consumed_uses", 0)))
        headroom = max(0, days - consumed - current_alloc)
        amount = min(max(0, raw_possible), headroom)
        target_additions.append({
            "appliance": app["name"],
            "added_uses": amount,
            "unit_label": app.get("unit_label", "use"),
            "raw_possible": raw_possible,
        })

    if all(ta["added_uses"] <= 0 for ta in target_additions):
        return {"success": False, "error": "Released budget is not enough to add one use to any target."}

    source_reductions = [_build_reduction(app, uses) for app, uses in sources]

    option = {
        "id": 0,
        "kind": "transfer",
        "from_appliances": [
            {"name": app["name"], "released_uses": uses, "unit_label": app.get("unit_label", "use")}
            for app, uses in sources
        ],
        "to_appliances": target_additions,
        "style": "Transfer",
        "title": f"Transfer: {', '.join(a['name'] for a,_ in sources)} → {', '.join(a['name'] for a in targets)}",
        "subtitle": f"Total freed: ${total_freed:.2f}. " + " | ".join(
            f"Add {ta['added_uses']} {ta['unit_label']}(s) to {ta['appliance']}"
            for ta in target_additions if ta["added_uses"] > 0
        ),
        "reductions": source_reductions,
        "reduction_summary": "; ".join(
            [f"Release {uses} {app.get('unit_label','use')}(s) from {app['name']}" for app, uses in sources] +
            [f"Add {ta['added_uses']} {ta['unit_label']}(s) to {ta['appliance']}" for ta in target_additions if ta["added_uses"] > 0]
        ),
    }

    return {"success": True, "options": [option]}


def apply_generated_option(user, option):
    kind = option.get("kind")
    days = _billing_days(user)

    if kind == "preference":
        target = _find_by_name(user, option.get("preferred_appliance", ""))

        if not target:
            return False, "Preferred appliance not found."

        add_uses = int(option.get("preferred_extra", 0))

        if add_uses > 0:
            current = _current_uses(target, days)
            consumed = max(0, int(target.get("consumed_uses", 0)))

            # ONLY billing period is the max
            headroom = max(0, days - consumed - current)

            if headroom <= 0:
                return False, f"{target['name']} has reached the maximum usage for this billing period."

            if add_uses > headroom:
                return False, f"Only {headroom} more use(s) can be added to {target['name']} this billing period."

            _increment_current_uses(target, add_uses, days)

            # Increase Uses Wanted so the dashboard reflects the new requested amount
            target["desired_uses"] = min(
                days,
                max(
                    int(target.get("desired_uses", 0)),
                    int(target.get("allocated_uses", 0)) + consumed
                )
            )

        for r in option.get("reductions", []):
            app = _find_by_name(user, r.get("appliance", ""))
            if app:
                _set_current_uses(app, r.get("remaining_after", 0), days)

        return True, f"Added {add_uses} extra use(s) to {target['name']}."

    if kind == "overuse":
        target = _find_by_name(user, option.get("appliance", ""))

        if not target:
            return False, "Appliance not found."

        extra_uses = int(option.get("extra_uses", 0))

        if extra_uses > 0:
            current = _current_uses(target, days)
            consumed = max(0, int(target.get("consumed_uses", 0)))
            headroom = max(0, days - consumed - current)

            if headroom <= 0:
                return False, f"{target['name']} has reached the maximum usage for this billing period."

            if extra_uses > headroom:
                return False, f"Only {headroom} more use(s) can be added to {target['name']} this billing period."

            _increment_current_uses(target, extra_uses, days)

            target["desired_uses"] = min(
                days,
                max(
                    int(target.get("desired_uses", 0)),
                    int(target.get("allocated_uses", 0)) + consumed
                )
            )

        for r in option.get("reductions", []):
            app = _find_by_name(user, r.get("appliance", ""))
            if app:
                _set_current_uses(app, r.get("remaining_after", 0), days)

        return True, "Correction applied and current allocation updated."

    if kind == "transfer":
        from_appliances = option.get("from_appliances")
        to_appliances_list = option.get("to_appliances")

        if from_appliances and to_appliances_list:
            for src_info in from_appliances:
                src = _find_by_name(user, src_info.get("name", ""))
                if src:
                    released = int(src_info.get("released_uses", 0))
                    current_src = _current_uses(src, days)
                    _set_current_uses(src, max(0, current_src - released), days)

            for tgt_info in to_appliances_list:
                tgt = _find_by_name(user, tgt_info.get("appliance", ""))

                if tgt:
                    add_uses = int(tgt_info.get("added_uses", 0))

                    if add_uses <= 0:
                        continue

                    current = _current_uses(tgt, days)
                    consumed = max(0, int(tgt.get("consumed_uses", 0)))

                    # ONLY billing period is the max
                    headroom = max(0, days - consumed - current)

                    if headroom <= 0:
                        return False, f"{tgt['name']} has reached the maximum usage for this billing period."

                    if add_uses > headroom:
                        return False, f"Only {headroom} more use(s) can be added to {tgt['name']} this billing period."

                    _increment_current_uses(tgt, add_uses, days)

                    # Increase Uses Wanted so it reflects the new allocation
                    tgt["desired_uses"] = min(
                        days,
                        max(
                            int(tgt.get("desired_uses", 0)),
                            int(tgt.get("allocated_uses", 0)) + consumed
                        )
                    )

        else:
            # Legacy transfer format
            source = _find_by_name(user, option.get("from_appliance", ""))
            target = _find_by_name(user, option.get("to_appliance", ""))

            if not source or not target:
                return False, "Transfer appliances not found."

            released = int(option.get("released_uses", 0))
            source_current = _current_uses(source, days)
            _set_current_uses(source, max(0, source_current - released), days)

            added = int(option.get("target_added_uses", 0))

            if added > 0:
                current = _current_uses(target, days)
                consumed = max(0, int(target.get("consumed_uses", 0)))
                headroom = max(0, days - consumed - current)

                if headroom <= 0:
                    return False, f"{target['name']} has reached the maximum usage for this billing period."

                if added > headroom:
                    return False, f"Only {headroom} more use(s) can be added to {target['name']} this billing period."

                _increment_current_uses(target, added, days)

                target["desired_uses"] = min(
                    days,
                    max(
                        int(target.get("desired_uses", 0)),
                        int(target.get("allocated_uses", 0)) + consumed
                    )
                )

        return True, "Transfer applied and current allocation updated."

    return False, "Invalid option."


def run_what_if(user, scenario):
    """
    Run a what-if scenario.
    scenario: {
      modify: [{name, desired_uses?, hours_per_use?, watts?, priority?, quantity?}],
      add: [{name, watts, desired_uses, hours_per_use, priority, quantity, unit_label?}],
      remove: [name, ...]
    }
    """
    clone = deepcopy(user)

    for name in scenario.get("remove", []):
        clone["appliances"] = [a for a in clone.get("appliances", []) if a["name"] != name]

    for mod in scenario.get("modify", []):
        app = _find_by_name(clone, mod.get("name", ""))
        if app:
            for field in ["desired_uses", "hours_per_use", "watts", "priority", "quantity"]:
                if field in mod:
                    try:
                        value = float(mod[field]) if field in ("hours_per_use", "watts") else int(mod[field])
                        if field == "desired_uses":
                            value = min(max(0, int(value)), _billing_days(clone))
                        app[field] = value
                    except (ValueError, TypeError):
                        pass
            app["allocated_uses"] = None

    from data import default_appliances as _defaults
    for new_app in scenario.get("add", []):
        name = str(new_app.get("name", "")).strip()
        if not name:
            continue
        d = _defaults.get(name, {})
        clone["appliances"].append({
            "name": name,
            "watts": float(new_app.get("watts", d.get("watts", 100))),
            "desired_uses": min(max(0, int(new_app.get("desired_uses", d.get("default_desired_uses", 1)))), _billing_days(clone)),
            "hours_per_use": float(new_app.get("hours_per_use", d.get("hours_per_use", 1))),
            "priority": int(new_app.get("priority", d.get("priority", 5))),
            "quantity": int(new_app.get("quantity", 1)),
            "unit_label": new_app.get("unit_label", d.get("unit_label", "use")),
            "consumed_uses": 0,
            "allocated_uses": None,
        })

    result = optimize_usage(clone, use_allocated_if_present=False)
    return {"success": result.get("status") == "Success", "result": result, "error": result.get("error")}