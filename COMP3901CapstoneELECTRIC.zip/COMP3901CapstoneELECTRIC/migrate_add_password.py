"""
One-time migration: adds password_hash column to the users table.
Safe to run multiple times — skips if the column already exists.

Usage:
    python migrate_add_password.py
"""
from db import engine
from sqlalchemy import text

with engine.connect() as conn:
    # Check if column already exists
    result = conn.execute(text("""
        SELECT column_name FROM information_schema.columns
        WHERE table_name = 'users' AND column_name = 'password_hash'
    """))
    if result.fetchone():
        print("Column password_hash already exists — nothing to do.")
    else:
        conn.execute(text("ALTER TABLE users ADD COLUMN password_hash VARCHAR;"))
        conn.commit()
        print("Done — password_hash column added to users table.")