import re
import os
from user_manager import (
    add_appliance, load_user_data, save_user_data, clear_user_appliances,
    set_password, verify_password, has_password, user_exists,
    log_consumption, reset_consumption,
)
from db import engine, Base
import models
from copy import deepcopy
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from data import default_appliances, FIXED_RATE
from energy_calculator import calculate_desired_plan_cost
from optimization_engine import (
    optimize_usage,
    save_current_allocation,
    build_usage_summary,
    generate_preference_options,
    generate_overuse_options,
    generate_transfer_options,
    apply_generated_option,
    allocate_remaining_budget,
    run_what_if,
    _find_by_name,
)
Base.metadata.create_all(bind=engine)
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY")

PRIORITY_LABELS = {
    10: "Critical", 9: "Very Important", 8: "Important",
    7: "Regular Use", 6: "Moderate", 5: "Neutral",
    4: "Flexible", 3: "Low Priority", 2: "Rarely Needed", 1: "Optional"
}

@app.template_filter('priority_label')
def priority_label_filter(value):
    try:
        return PRIORITY_LABELS.get(int(value), f"{value}/10")
    except (TypeError, ValueError):
        return str(value)

APPLIANCE_NAME_RE = re.compile(r"^[A-Za-z\s]{1,60}$")
 
BOUNDS = {
    "budget":        (0.01,  999_999.99),
    "rate":          (0.01,   999.99),
    "days":          (1,      365),
    "watts":         (1.0,    10_000.0),
    "desired_uses":  (0,      365),
    "quantity":      (1,      20),
    "priority":      (1,      10),
}
 
 
def _validate_name(raw):
    #Return cleaned name or None if invalid.
    cleaned = raw.strip()
    if not APPLIANCE_NAME_RE.match(cleaned):
        return None
    return cleaned
 
 
def _clamp(value, key):
    lo, hi = BOUNDS[key]
    return max(lo, min(hi, value))
 
 
def _safe_float(raw, key, fallback=None):
    try:
        return _clamp(float(raw), key)
    except (TypeError, ValueError):
        return fallback if fallback is not None else BOUNDS[key][0]
 
 
def _safe_int(raw, key, fallback=None):
    try:
        return _clamp(int(float(raw)), key)
    except (TypeError, ValueError):
        return fallback if fallback is not None else BOUNDS[key][0]

def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None, None
    user = load_user_data(user_id)
    return user_id, user


def build_dashboard_payload(user):
    desired_plan = calculate_desired_plan_cost(user)
    optimized = optimize_usage(user, use_allocated_if_present=True)
    usage_summary = build_usage_summary(optimized)
    return {
        "desired_plan": desired_plan,
        "optimized": optimized,
        "usage_summary": usage_summary,
        "initial_optimized": user.get("initial_optimized_plan")
    }


def remember_initial_plan(user, user_id):
    if not user.get("initial_optimized_plan"):
        first = optimize_usage(deepcopy(user), use_allocated_if_present=False)
        if first.get("status") == "Success":
            user["initial_optimized_plan"] = first
            save_user_data(user_id, user)


@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        raw_id = request.form.get("user_id", "").strip()
        pin = request.form.get("pin", "").strip()
        pin_confirm = request.form.get("pin_confirm", "").strip()

        if not raw_id:
            return render_template("login.html", error="Enter a House ID.")
        if not re.match(r"^[A-Za-z0-9_\-]{1,40}$", raw_id):
            return render_template("login.html", error="House ID may only contain letters, numbers, hyphens, and underscores.")

        if not pin or not re.match(r"^\d{4,8}$", pin):
            return render_template("login.html", error="PIN must be 4-8 digits.")

        existing = user_exists(raw_id)

        if existing and has_password(raw_id):
            if not verify_password(raw_id, pin):
                return render_template("login.html", error="Incorrect PIN. Try again.", user_id=raw_id, returning=True)
            session["user_id"] = raw_id
            return redirect(url_for("dashboard"))
        else:
            if not pin_confirm:
                return render_template("login.html", user_id=raw_id, needs_confirm=True)
            if pin != pin_confirm:
                return render_template("login.html", error="PINs do not match. Try again.", user_id=raw_id, needs_confirm=True)
            load_user_data(raw_id)
            set_password(raw_id, pin)
            session["user_id"] = raw_id
            return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/api/catalog")
def api_catalog():
    from data import default_appliances
    return jsonify(default_appliances)


@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    user_id, user = current_user()

    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        #Step 1 — save budget/rate/days and clear appliances
        user["budget"] = _safe_float(request.form.get("budget"), "budget", 0)
        user["rate"] = _safe_float(request.form.get("rate"), "rate", FIXED_RATE)
        user["days"] = _safe_int(request.form.get("days"), "days", 30)
        user["appliances"] = []
        clear_user_appliances(user_id)
        user["initial_optimized_plan"] = None

        #Reset consumption tracking for the new billing period
        from datetime import date
        user["period_start_date"] = date.today().isoformat()
        reset_consumption(user_id)

        #Save budget/rate/days to DB first
        save_user_data(user_id, user)

        #Step 2 — add appliances to DB one by one
        names = request.form.getlist("appliance_name")
        watts = request.form.getlist("appliance_watts")
        uses = request.form.getlist("appliance_desired_uses")
        quantities = request.form.getlist("appliance_quantity")
        priorities = request.form.getlist("appliance_priority")
        hours_list = request.form.getlist("appliance_hours_per_use")

        for i, name in enumerate(names):
            name = name.strip()

            if not name or i >= len(watts) or not watts[i]:
                continue

            add_appliance(
                user_id,
                name,
                watts[i],
                uses[i] if i < len(uses) and uses[i] else 0,
                quantities[i] if i < len(quantities) and quantities[i] else 1,
                priorities[i] if i < len(priorities) and priorities[i] else 5,
                hours_list[i] if i < len(hours_list) and hours_list[i] else None,
            )

        #Step 3 — reload user from DB so appliances are included
        user = load_user_data(user_id)

        #Step 4 — generate and save the initial optimized plan
        remember_initial_plan(user, user_id)

        #Step 5 — save first budget-safe allocation
        first_plan = optimize_usage(user, use_allocated_if_present=False)
        if first_plan.get("status") == "Success":
            save_current_allocation(user, first_plan)
            save_user_data(user_id, user)

        #Step 6 — reload fresh from DB before rendering
        user = load_user_data(user_id)

    payload = build_dashboard_payload(user)

    return render_template(
        "index.html",
        user_id=user_id,
        user=user,
        defaults=default_appliances,
        desired_plan=payload["desired_plan"],
        optimized=payload["optimized"],
        initial_optimized=payload["initial_optimized"],
        usage_summary=payload["usage_summary"],
        already_spent=payload["optimized"].get("already_spent", 0),
        period_start_date=user.get("period_start_date"),
    )


@app.post("/apply-budget-safe-plan")
def apply_budget_safe_plan():
    user_id, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    optimized = optimize_usage(user, use_allocated_if_present=False)

    if optimized.get("status") != "Success":
        return jsonify(success=False, error=optimized.get("error", "Optimization failed."))

    save_current_allocation(user, optimized)
    save_user_data(user_id, user)
    # Reload so payload is built from saved DB state, not stale in-memory dict
    user = load_user_data(user_id)

    payload = build_dashboard_payload(user)
    return jsonify(success=True, message="Budget-safe plan applied as your current allocation.", **payload)


@app.post("/use-remaining-budget")
def use_remaining_budget():
    user_id, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(silent=True) or {}
    selected = data.get("selected_indexes", [])

    ok, message, new_plan = allocate_remaining_budget(user, selected)

    if ok:
        # Save the updated allocated_uses back to the database
        # BEFORE building the payload so the dashboard reflects the new values
        save_user_data(user_id, user)
        # Reload fresh from DB so build_dashboard_payload reads saved state
        user = load_user_data(user_id)

    payload = build_dashboard_payload(user)
    return jsonify(success=ok, message=message, error=None if ok else message, **payload)


@app.post("/generate-preference-options")
def preference_options():
    _, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}
    return jsonify(generate_preference_options(
        user,
        data.get("preferred_appliance", ""),
        data.get("preferred_extra", 0)
    ))


@app.post("/generate-overuse-options")
def overuse_options():
    _, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}
    return jsonify(generate_overuse_options(
        user,
        data.get("appliance", ""),
        data.get("extra_uses", 0)
    ))


@app.post("/generate-transfer-options")
def transfer_options():
    _, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}
    #Support both single and multi source/target
    from_appliances = data.get("from_appliances") or ([data.get("from_appliance")] if data.get("from_appliance") else [])
    released_uses_list = data.get("released_uses_list") or ([data.get("released_uses", 0)])
    to_appliances = data.get("to_appliances") or ([data.get("to_appliance")] if data.get("to_appliance") else [])

    return jsonify(generate_transfer_options(
        user,
        from_appliances,
        released_uses_list,
        to_appliances,
    ))


@app.post("/apply-option")
def apply_option():
    user_id, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}
    selected = data.get("option")

    if not selected:
        return jsonify(success=False, error="No option was sent.")

    ok, message = apply_generated_option(user, selected)

    if ok:
        save_user_data(user_id, user)
        user = load_user_data(user_id)

    payload = build_dashboard_payload(user)
    return jsonify(success=ok, message=message, error=None if ok else message, **payload)


@app.post("/what-if")
def what_if():
    _, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}
    #Accept new scenario format {modify, add, remove}
    scenario = {
        "modify": data.get("modify", []),
        "add": data.get("add", []),
        "remove": data.get("remove", []),
    }
    return jsonify(run_what_if(user, scenario))


@app.post("/apply-what-if")
def apply_what_if():
    #Apply what-if scenario changes to the user's actual appliances.
    user_id, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}

    from models import Appliance as ApplianceModel
    from db import SessionLocal as _SessionLocal
    from data import default_appliances as _defaults

    db = _SessionLocal()

    #Remove appliances from DB
    for name in data.get("remove", []):
        db.query(ApplianceModel).filter(
            ApplianceModel.user_id == user_id,
            ApplianceModel.name == name
        ).delete()

    #Modify existing appliances in DB
    for mod in data.get("modify", []):
        name = mod.get("name", "")
        app_row = db.query(ApplianceModel).filter(
            ApplianceModel.user_id == user_id,
            ApplianceModel.name == name
        ).first()
        if app_row:
            if "desired_uses" in mod:
                try: app_row.desired_uses = min(max(0, int(mod["desired_uses"])), max(1, int(user.get("days", 30))))
                except: pass
            if "hours_per_use" in mod and mod["hours_per_use"]:
                try: app_row.hours_per_use = float(mod["hours_per_use"])
                except: pass
            if "watts" in mod:
                try: app_row.watts = float(mod["watts"])
                except: pass
            if "priority" in mod:
                try: app_row.priority = int(mod["priority"])
                except: pass
            app_row.allocated_uses = None
            app_row.default_desired_uses = app_row.desired_uses  # keep in sync

    db.commit()
    db.close()

    #Add new appliances
    for new_app in data.get("add", []):
        name = str(new_app.get("name", "")).strip()
        if not name:
            continue
        d = _defaults.get(name, {})
        add_appliance(
            user_id, name,
            new_app.get("watts", d.get("watts", 100)),
            new_app.get("desired_uses", d.get("default_desired_uses", 1)),
            1,
            new_app.get("priority", d.get("priority", 5)),
            new_app.get("hours_per_use", d.get("hours_per_use", None)),
        )

    #Reload fresh from DB (picks up all removes, modifies, adds)
    user = load_user_data(user_id)

    #Re-optimize
    fresh_plan = optimize_usage(user, use_allocated_if_present=False)
    if fresh_plan.get("status") == "Success":
        save_current_allocation(user, fresh_plan)
        save_user_data(user_id, user)
        user = load_user_data(user_id)

    payload = build_dashboard_payload(user)
    return jsonify(success=True, message="Changes applied to your appliances.", user_appliances=user.get("appliances", []), **payload)


@app.post("/log-consumption")
def log_consumption_route():
    
    ##Record that a user actually used an appliance.
    ##Accepts any amount even if it exceeds the original allocation.
    ##Always re-optimizes remaining appliances around whatever budget is left.
    
    
    user_id, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    data = request.get_json(force=True) or {}
    appliance_name = data.get("appliance", "").strip()
    uses = data.get("uses", 1)

    try:
        uses = max(1, int(uses))
    except (TypeError, ValueError):
        uses = 1

    if not appliance_name:
        return jsonify(success=False, error="Appliance name is required.")

    ok, message, new_total = log_consumption(user_id, appliance_name, uses)

    if not ok:
        return jsonify(success=False, error=message)

    #Reload fresh data so optimizer sees updated consumed_uses
    user = load_user_data(user_id)

    #Always re-optimize even if budget is exceeded, effective_budget
    #floors at 0 so the LP runs cleanly and shows zero remaining allocation
    #for all appliances, reflecting that there is nothing left to spend
    updated_plan = optimize_usage(user, use_allocated_if_present=False)

    if updated_plan.get("status") == "Success":
        #Write the new lower allocations back into the in-memory user dict
        save_current_allocation(user, updated_plan)
        #Persist those new allocated_uses to the database
        save_user_data(user_id, user)
        #Reload fresh from DB so the payload reflects exactly what was saved
        user = load_user_data(user_id)

    payload = build_dashboard_payload(user)

    #Surface the overrun flag from the optimizer so the frontend
    #can show a warning without blocking the updated dashboard
    overrun = updated_plan.get("overrun", False)
    overspend = updated_plan.get("overspend", 0)

    return jsonify(
        success=True,
        message=message,
        new_consumed_total=new_total,
        already_spent=payload["optimized"].get("already_spent", 0),
        overrun=overrun,
        overspend=overspend,
        **payload,
    )


@app.post("/reset-period")
def reset_period():
    
    #Start a new billing period zeros out all consumed_uses,
    #resets desired_uses to defaults, clears initial_optimized_plan,
    #resets period_start_date to today, and re-optimizes against
    #the full budget with original desired uses.
    
    user_id, user = current_user()

    if not user:
        return jsonify(success=False, error="No user session.")

    #Reset all usage state (keeps appliances, resets consumed/allocated/desired)
    reset_consumption(user_id)
    user = load_user_data(user_id)

    #Generate and save a fresh initial plan
    first_plan = optimize_usage(deepcopy(user), use_allocated_if_present=False)
    if first_plan.get("status") == "Success":
        user["initial_optimized_plan"] = first_plan
        save_current_allocation(user, first_plan)
        save_user_data(user_id, user)
        user = load_user_data(user_id)

    payload = build_dashboard_payload(user)
    return jsonify(
        success=True,
        message="Billing period reset. All consumption cleared and plan re-optimized.",
        user_appliances=user.get("appliances", []),
        **payload,
    )


if __name__ == "__main__":
    app.run(debug=True)