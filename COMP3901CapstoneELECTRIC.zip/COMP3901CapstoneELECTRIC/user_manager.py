from sqlalchemy.orm.attributes import flag_modified
from data import default_appliances, FIXED_RATE
from db import SessionLocal
from models import User, Appliance, ApplianceCatalog
import bcrypt

def _hash_pin(pin: str) -> str:
    """Return a bcrypt hash string for the given PIN."""
    return bcrypt.hashpw(pin.encode(), bcrypt.gensalt()).decode()


def _verify_pin(pin: str, stored: str) -> bool:
    """Return True if PIN matches the bcrypt hash."""
    try:
        return bcrypt.checkpw(pin.encode(), stored.encode())
    except Exception:
        return False


def set_password(user_id: str, pin: str) -> bool:
    """Hash and store PIN for user. Returns True on success."""
    db = SessionLocal()
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        db.close()
        return False
    user.password_hash = _hash_pin(pin)
    db.commit()
    db.close()
    return True


def verify_password(user_id: str, pin: str) -> bool:
    """Return True if PIN matches stored hash."""
    db = SessionLocal()
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user or not user.password_hash:
        db.close()
        return False
    result = _verify_pin(pin, user.password_hash)
    db.close()
    return result

def has_password(user_id: str) -> bool:
    """Return True if this user already has a PIN set."""
    db = SessionLocal()
    user = db.query(User).filter(User.user_id == user_id).first()
    result = bool(user and user.password_hash)
    db.close()
    return result


def user_exists(user_id: str) -> bool:
    db = SessionLocal()
    exists = db.query(User).filter(User.user_id == user_id).first() is not None
    db.close()
    return exists


def _new_user():
    return {
        "budget": 0.0,
        "rate": FIXED_RATE,
        "days": 30,
        "appliances": [],
        "initial_optimized_plan": None,
    }


def _appliance_to_dict(app):
    return {
        "name": app.name,
        "watts": app.watts,
        "hours_per_use": app.hours_per_use,
        "quantity": app.quantity,
        "priority": app.priority,
        "usage_mode": app.usage_mode,
        "unit_label": app.unit_label,
        "desired_uses": app.desired_uses,
        "allocated_uses": app.allocated_uses,
        "default_desired_uses": app.default_desired_uses,
        # Dynamic tracking
        "consumed_uses": app.consumed_uses if app.consumed_uses is not None else 0,
    }


def load_user_data(user_id):
    db = SessionLocal()

    user = db.query(User).filter(User.user_id == user_id).first()

    if not user:
        user = User(
            user_id=user_id,
            budget=0.0,
            rate=FIXED_RATE,
            days=30,
            initial_optimized_plan=None,
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    appliances = db.query(Appliance).filter(
        Appliance.user_id == user_id
    ).all()

    data = {
        "budget": user.budget,
        "rate": user.rate,
        "days": user.days,
        "appliances": [_appliance_to_dict(a) for a in appliances],
        "initial_optimized_plan": user.initial_optimized_plan,
        # Dynamic tracking
        "period_start_date": user.period_start_date.isoformat() if user.period_start_date else None,
    }

    db.close()
    return data


def save_user_data(user_id, data=None):
    db = SessionLocal()

    user = db.query(User).filter(User.user_id == user_id).first()

    if not user:
        db.close()
        return

    if data:
        user.budget = data["budget"]
        user.rate = data["rate"]
        user.days = data["days"]
        user.initial_optimized_plan = data.get("initial_optimized_plan")

        flag_modified(user, "initial_optimized_plan")

        # Dynamic tracking — persist period start date if provided
        period_start = data.get("period_start_date")
        if period_start:
            from datetime import date
            if isinstance(period_start, str):
                user.period_start_date = date.fromisoformat(period_start)
            else:
                user.period_start_date = period_start

        # Update allocated_uses, desired_uses, and consumed_uses for each appliance
        for app_dict in data.get("appliances", []):
            app_row = db.query(Appliance).filter(
                Appliance.user_id == user_id,
                Appliance.name == app_dict["name"]
            ).first()

            if app_row:
                days = max(1, int(user.days or 30))
                if "desired_uses" in app_dict:
                    app_row.desired_uses = min(max(0, int(app_dict.get("desired_uses") or 0)), days)
                consumed = max(0, int(app_dict.get("consumed_uses", app_row.consumed_uses or 0)))
                # Hard cap is billing period length, not desired_uses
                max_alloc = max(0, days - consumed)
                raw_alloc = app_dict.get("allocated_uses")
                app_row.allocated_uses = None if raw_alloc is None else min(max(0, int(raw_alloc)), max_alloc)
                # Only update consumed_uses if explicitly present in the dict
                if "consumed_uses" in app_dict:
                    app_row.consumed_uses = min(max(0, int(app_dict["consumed_uses"])), days)

    db.commit()
    db.close()


def get_user(user_id):
    return load_user_data(user_id)


def _upsert_catalog(db, name, watts, meta):
    """Insert into shared catalog if the name is new; never overwrite built-ins."""
    if name in default_appliances:
        return  # built-in appliances are authoritative
    existing = db.query(ApplianceCatalog).filter(ApplianceCatalog.name == name).first()
    if not existing:
        db.add(ApplianceCatalog(
            name=name,
            watts=watts,
            hours_per_use=float(meta.get("hours_per_use", 1)),
            usage_mode=meta.get("usage_mode", "session_based"),
            unit_label=meta.get("unit_label", "use"),
            default_desired_uses=int(meta.get("default_desired_uses", 1)),
        ))


def add_appliance(user_id, name, watts, desired_uses, quantity=1, priority=5, hours_per_use = None):
    db = SessionLocal()

    user = db.query(User).filter(User.user_id == user_id).first()

    if not user:
        db.close()
        return False

    meta = default_appliances.get(name, {})

    days = max(1, int(user.days or 30))
    desired = min(max(0, int(float(desired_uses or 0))), days)

    # Delete existing appliance with same name for this user first
    db.query(Appliance).filter(
        Appliance.user_id == user_id,
        Appliance.name == name
    ).delete()

    new_appliance = Appliance(
        user_id=user_id,
        name=name,
        watts=float(watts),
        hours_per_use=float(hours_per_use) if hours_per_use else float(meta.get("hours_per_use", 1)),
        quantity=max(1, int(float(quantity or 1))),
        priority=min(10, max(1, int(float(priority or 5)))),
        usage_mode=meta.get("usage_mode", "session_based"),
        unit_label=meta.get("unit_label", "use"),
        desired_uses=desired,
        allocated_uses=None,
        default_desired_uses=int(meta.get("default_desired_uses", 1)),
        consumed_uses=0,
    )

    db.add(new_appliance)
    _upsert_catalog(db, name, float(watts), meta)
    db.commit()
    db.close()

    return True


def get_catalog():
    """Return the shared appliance catalog merged with the built-in defaults."""
    db = SessionLocal()
    rows = db.query(ApplianceCatalog).order_by(ApplianceCatalog.name).all()
    catalog = dict(default_appliances)  # start with built-ins
    for row in rows:
        if row.name not in catalog:
            catalog[row.name] = {
                "watts": row.watts,
                "hours_per_use": row.hours_per_use,
                "usage_mode": row.usage_mode,
                "unit_label": row.unit_label,
                "default_desired_uses": row.default_desired_uses,
                "priority": 5,
            }
    db.close()
    return catalog


def clear_user_appliances(user_id):
    db = SessionLocal()
    db.query(Appliance).filter(Appliance.user_id == user_id).delete()
    db.commit()
    db.close()


def log_consumption(user_id, appliance_name, uses_to_add):
    """
    Increment consumed_uses for one appliance by uses_to_add.
    Returns (success, message, new_consumed_total).
    """
    if uses_to_add <= 0:
        return False, "Uses to log must be greater than zero.", 0

    db = SessionLocal()

    user_row = db.query(User).filter(User.user_id == user_id).first()
    app_row = db.query(Appliance).filter(
        Appliance.user_id == user_id,
        Appliance.name == appliance_name
    ).first()

    if not app_row:
        db.close()
        return False, f"Appliance '{appliance_name}' not found.", 0

    days = max(1, int(user_row.days or 30)) if user_row else 30
    consumed = max(0, int(app_row.consumed_uses or 0))
    # Hard ceiling is billing period length, not desired_uses
    period_remaining = max(0, days - consumed)

    if period_remaining <= 0:
        db.close()
        return False, f"{appliance_name} has reached the maximum uses for this billing period ({days} days).", consumed
    if int(uses_to_add) > period_remaining:
        db.close()
        return False, f"Only {period_remaining} use(s) can be added for {appliance_name}; it would exceed the billing period.", consumed

    app_row.consumed_uses = consumed + int(uses_to_add)
    new_total = app_row.consumed_uses
    db.commit()
    db.close()
    return True, f"Logged {uses_to_add} use(s) for {appliance_name}.", new_total


def reset_consumption(user_id):
    """
    Start a fresh billing period:
    - Reset consumed_uses to 0 for all appliances
    - Reset allocated_uses to None (will be re-optimized)
    - Reset desired_uses back to default_desired_uses (original goal)
    - Clear initial_optimized_plan so a fresh one is generated
    - Set period_start_date to today
    Appliances are kept intact.
    """
    from datetime import date
    db = SessionLocal()

    appliances = db.query(Appliance).filter(Appliance.user_id == user_id).all()
    for app in appliances:
        app.consumed_uses = 0
        app.allocated_uses = None
        # Reset desired_uses back to the original goal
        if app.default_desired_uses and app.default_desired_uses > 0:
            app.desired_uses = app.default_desired_uses

    user = db.query(User).filter(User.user_id == user_id).first()
    if user:
        user.period_start_date = date.today()
        user.initial_optimized_plan = None  # will be regenerated

    db.commit()
    db.close()