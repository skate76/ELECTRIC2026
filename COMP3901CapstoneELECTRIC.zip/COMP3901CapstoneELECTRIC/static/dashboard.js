const priorityDescriptions = {
    10: "Cannot realistically reduce this appliance.",
    9: "Strongly protected from reductions.",
    8: "Prefer to keep this appliance active.",
    7: "Used often in normal daily life.",
    6: "Useful but somewhat flexible.",
    5: "Average importance appliance.",
    4: "Can be reduced if necessary.",
    3: "One of the first appliances reduced.",
    2: "Only occasionally needed.",
    1: "Only used if budget allows."
};

const priorityLabels = {
    10: "Critical", 9: "Very Important", 8: "Important",
    7: "Regular Use", 6: "Moderate", 5: "Neutral",
    4: "Flexible", 3: "Low Priority", 2: "Rarely Needed", 1: "Optional"
};

function plural(label, n) {
    return `${label}${Number(n) === 1 ? '' : 's'}`;
}

function money(value) {
    return `$${Number(value || 0).toFixed(2)}`;
}

function getDays() {
    return parseInt(document.getElementById('fin-days')?.value) || parseInt(document.getElementById('ob-days')?.value) || 30;
}

function showMessage(message, isError = false) {
    const box = document.getElementById('live-message');
    box.textContent = message || '';
    box.className = isError ? 'message error' : 'message';
    box.style.display = message ? 'block' : 'none';
    if (message) {
        box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function switchView(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById('view-' + view).classList.add('active');
}

function saveBudgetDetails() {
    document.getElementById('hidden-budget').value = document.getElementById('fin-budget').value.trim() || 0;
    document.getElementById('hidden-rate').value = document.getElementById('fin-rate').value.trim() || 45.46;
    document.getElementById('hidden-days').value = document.getElementById('fin-days').value.trim() || 30;
    switchView('appliances');
}

function submitApplianceForm() {
    const rows = [...document.querySelectorAll('.appliance-row')];
    const hasAppliance = rows.some(row => {
        const hiddenName = row.querySelector('.appliance-name-value');
        return hiddenName && hiddenName.value.trim() !== '';
    });

    const errorBox = document.getElementById('appliance-error');

    if (!hasAppliance) {
        errorBox.style.display = 'block';
        return;
    }

    if (formHasErrors()) {
        showMessage('Please fix the highlighted errors before submitting.', true);
        return;
    }
    errorBox.style.display = 'none';
    document.getElementById('main-form').submit();
}

function updatePriorityMeaning(selectEl) {
    const help = selectEl.parentElement.querySelector('.priority-help');
    if (help) help.textContent = priorityDescriptions[selectEl.value] || '';
}

function handleApplianceSelect(selectEl) {
    const row = selectEl.closest('.appliance-row');
    const hiddenName = row.querySelector('.appliance-name-value');
    const customInput = row.querySelector('.custom-name-input');
    const selected = selectEl.value;

    if (selected === '__custom__') {
        customInput.style.display = 'block';
        customInput.focus();
        hiddenName.value = '';
    } else if (selected === '') {
        customInput.style.display = 'none';
        hiddenName.value = '';
    } else {
        customInput.style.display = 'none';
        hiddenName.value = selected;

        const info = applianceDefaults[selected];
        if (info) {
            row.querySelector('input[name="appliance_watts"]').value = info.watts;
            const prioritySelect = row.querySelector('select[name="appliance_priority"]');
            prioritySelect.value = info.priority;
            updatePriorityMeaning(prioritySelect);
            const hoursInput = row.querySelector('input[name="appliance_hours_per_use"]');
            if (hoursInput) hoursInput.value = info.hours_per_use || '';
        }
    }
}

function syncCustomName(inputEl) {
    inputEl.closest('.appliance-row').querySelector('.appliance-name-value').value = inputEl.value;
}

function buildDefaultOptions() {
    let html = `<option value="">-- Select --</option>`;
    for (const [name, info] of Object.entries(applianceDefaults)) {
        html += `<option value="${name}" data-watts="${info.watts}" data-priority="${info.priority||5}" data-hours="${info.hours_per_use||''}">${name}</option>`;
    }
    html += `<option value="__custom__">Custom</option>`;
    return html;
}

function prioritySelectHtml() {
    const opts = [
        [10,'Critical','Cannot realistically reduce this appliance.'],
        [9,'Very Important','Strongly protected from reductions.'],
        [8,'Important','Prefer to keep this appliance active.'],
        [7,'Regular Use','Used often in normal daily life.'],
        [6,'Moderate','Useful but somewhat flexible.'],
        [5,'Neutral','Average importance appliance.'],
        [4,'Flexible','Can be reduced if necessary.'],
        [3,'Low Priority','One of the first appliances reduced.'],
        [2,'Rarely Needed','Only occasionally needed.'],
        [1,'Optional','Only used if budget allows.'],
    ];
    return `
        <label class="muted">Priority <span style="font-size:11px;cursor:help;" title="Priority determines which appliances keep their full allocation when the budget is tight.">ⓘ</span></label>
        <select name="appliance_priority" onchange="updatePriorityMeaning(this)">
            ${opts.map(([v,l,d]) => `<option value="${v}" title="${d}"${v===5?' selected':''}>${l}</option>`).join('')}
        </select>
        <div class="priority-help muted" style="font-size:12px; margin-top:5px;">Average importance appliance.</div>
    `;
}

async function addApplianceRow() {
    try {
        const res = await fetch('/api/catalog');
        if (res.ok) {
            const fresh = await res.json();
            Object.assign(applianceDefaults, fresh);
        }
    } catch (e) {}

    document.getElementById('appliance-list').insertAdjacentHTML('beforeend', `
        <div class="appliance-row">
            <div>
                <label class="muted">Appliance</label>
                <input type="hidden" name="appliance_name" class="appliance-name-value" value="">
                <select class="appliance-select" onchange="handleApplianceSelect(this)">${buildDefaultOptions()}</select>
                <input type="text" class="custom-name-input" placeholder="Appliance name" style="display:none; margin-top:6px;" oninput="syncCustomName(this)">
            </div>
            <div>
                <label class="muted">Watts</label>
                <input name="appliance_watts" type="number" placeholder="e.g. 200" min="1" max="10000" oninput="validateField(this, 1, 10000, 'Max 10,000W for household appliances')">
                <div class="field-error">Max 10,000W for household appliances</div>
            </div>
            <div>
                <label class="muted">Uses Wanted (Days/Month)</label>
                <input name="appliance_desired_uses" type="number" min="0" max="365" placeholder="0 = auto" oninput="validateField(this, 0, 365, 'Max 365 uses (once per day)')">
                <div class="field-error">Max 365 uses (once per day)</div>
            </div>
            <div>
                <label class="muted">Hrs/Use</label>
                <input name="appliance_hours_per_use" type="number" min="0.1" max="24" step="0.1" placeholder="auto" title="Leave blank to use the default for this appliance type" oninput="validateField(this, 0.1, 24, 'Hours must be between 0.1 and 24')">
                <div class="field-error">Hours must be between 0.1 and 24</div>
            </div>
            <div>
                <label class="muted">Priority</label>
                ${prioritySelectHtml()}
            </div>
            <button type="button" class="btn btn-danger" onclick="this.closest('.appliance-row').remove()">X</button>
        </div>
    `);
}

async function withSpinner(btn, action) {
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="btn-spinner"></span>' + btn.innerText.trim();
    try {
        await action();
    } finally {
        btn.disabled = false;
        btn.innerHTML = original;
    }
}

async function postJSON(url, payload = {}) {
    const res = await fetch(url, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    });

    const text = await res.text();

    try {
        return JSON.parse(text);
    } catch (err) {
        console.error(text);
        return { success: false, error: "Server returned non-JSON. Check Flask console for errors." };
    }
}

function updateDashboardFromPayload(data) {
    if (!data) return;

    if (data.optimized && data.optimized.optimized_plan) {
        if (data.user_appliances) {
            currentAppliances = data.user_appliances;
        }
    }

    if (data.optimized && data.optimized.status === 'Success') {
        currentOptimized = data.optimized;
        renderOptimizedPlan(currentOptimized);
        renderUsageSummary(data.usage_summary || []);
        populateDashboardSelects(currentOptimized);
        renderRemainingBudgetCheckboxes(currentOptimized);
        renderChart(currentOptimized, currentChartType);
        renderCostAlerts(currentOptimized);

        const totalAllocEl = document.getElementById('total-allocation-value');
        if (totalAllocEl) totalAllocEl.textContent = money(data.optimized.total_cost || 0);

        const banner = document.getElementById('overrun-banner');
        if (banner) {
            if (data.overrun && data.overspend > 0) {
                banner.style.display = '';
                banner.innerHTML = `⚠️ <strong>Budget exceeded.</strong>
                    Your actual consumption has gone over your original budget by
                    <strong>J$${parseFloat(data.overspend).toFixed(2)}</strong>.
                    All remaining allocations have been set to zero.
                    You can start a new billing period or increase your budget in the setup.`;
            } else {
                banner.style.display = 'none';
                banner.innerHTML = '';
            }
        }
    }

    if (data.desired_plan) {
        document.getElementById('desired-total').textContent = money(data.desired_plan.total_cost);
        const status = document.getElementById('desired-status');
        status.textContent = data.desired_plan.budget_warning ? 'Above Budget' : 'Within Budget';
        status.className = data.desired_plan.budget_warning ? 'over' : 'ok';
    }
}

function renderOptimizedPlan(optimized) {
    const tbody = document.getElementById('optimized-plan-body');
    if (!tbody || !optimized || optimized.status !== 'Success') return;

    tbody.innerHTML = '';

    optimized.optimized_plan.forEach((item, idx) => {
        const consumed = item.consumed_uses || 0;
        const consumedHtml = consumed > 0
            ? `<span style="color:var(--warning);font-weight:bold;">${consumed} ${plural(item.unit_label, consumed)}</span>`
            : `<span class="muted">0</span>`;
        const inputId = `log-uses-dyn-${idx}`;
        const priLabel = priorityLabels[item.priority] || `${item.priority}/10`;
        const priDesc = priorityDescriptions[item.priority] || '';

        tbody.insertAdjacentHTML('beforeend', `
            <tr>
                <td>${item.name}</td>
                <td><span class="priority-badge">${priLabel}<span class="priority-tooltip">${priDesc}</span></span></td>
                <td>${item.desired_uses} ${plural(item.unit_label, item.desired_uses)}</td>
                <td>${consumedHtml}</td>
                <td><span class="chip">${item.allowed_uses} ${plural(item.unit_label, item.allowed_uses)}</span></td>
                <td>${money(item.cost)}</td>
                <td>
                    <input type="number" id="${inputId}" min="0" max="999" value="0"
                        data-appliance="${item.name}"
                        class="log-uses-input"
                        style="width:70px;padding:6px;font-size:13px;">
                </td>
            </tr>
        `);
    });

    document.getElementById('already-spent-value').textContent = money(optimized.already_spent || 0);
    document.getElementById('optimized-total').textContent = money(optimized.budget_remaining || 0);

    const totalAllocEl = document.getElementById('total-allocation-value');
    if (totalAllocEl) totalAllocEl.textContent = money(optimized.total_cost || 0);
}

// ── Animated bars ──────────────────────────────────────────────────────────
function renderUsageSummary(summary) {
    const wrap = document.getElementById('usage-summary-wrap');
    if (!wrap) return;

    wrap.innerHTML = '';

    if (!summary || summary.length === 0) {
        wrap.innerHTML = `<div class="option-box muted">No usage summary available.</div>`;
        return;
    }

    summary.forEach(row => {
        let barClass = '';
        if (row.percent >= 90) barClass = 'bar-danger';
        else if (row.percent >= 60) barClass = 'bar-warn';

        const consumed = row.consumed_uses || 0;
        const consumedNote = consumed > 0
            ? ` • <span style="color:var(--warning);">${consumed} already used</span>`
            : '';

        wrap.insertAdjacentHTML('beforeend', `
            <div class="usage-card">
                <strong>${row.name}</strong>
                <div class="bar-wrap">
                    <div class="bar ${barClass}" data-target="${row.percent}" style="width:0%"></div>
                </div>
                <div class="muted">
                    ${row.allowed_uses} of ${row.remaining_uses !== undefined ? row.remaining_uses : row.desired_uses} ${plural(row.unit_label, row.desired_uses)}
                    remaining allocated • ${row.percent}% • Cost: ${money(row.cost)}${consumedNote}
                </div>
            </div>
        `);
    });

    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            wrap.querySelectorAll('.bar[data-target]').forEach(bar => {
                bar.style.width = bar.dataset.target + '%';
            });
        });
    });
}
// ─────────────────────────────────────────────────────────────────────────

function optionSelectHtml(optimized) {
    if (!optimized || optimized.status !== 'Success') return '<option value="">-- Select --</option>';

    let html = '<option value="">-- Select --</option>';
    optimized.optimized_plan.forEach(item => {
        html += `<option value="${item.name}">${item.name}</option>`;
    });
    return html;
}

function populateDashboardSelects(optimized) {
    const html = optionSelectHtml(optimized);

    ['preferred_appliance'].forEach(id => {
        const select = document.getElementById(id);
        if (select) {
            const oldValue = select.value;
            select.innerHTML = html;
            if ([...select.options].some(o => o.value === oldValue)) select.value = oldValue;
        }
    });

    refreshTransferSelects(optimized);
    initWhatIfTable(optimized);
}

function renderRemainingBudgetCheckboxes(optimized) {
    const wrap = document.getElementById('remaining-budget-checkboxes');
    if (!wrap || !optimized || optimized.status !== 'Success') return;

    wrap.innerHTML = '';

    optimized.optimized_plan.forEach(item => {
        wrap.insertAdjacentHTML('beforeend', `
            <label class="checkbox-row">
                <input type="checkbox" class="remaining-budget-choice" value="${item.index}" checked>
                <span>${item.name}</span>
            </label>
        `);
    });
}

async function applyBudgetSafePlan() {
    const data = await postJSON('/apply-budget-safe-plan');

    if (!data.success) {
        showMessage(data.error || 'Could not apply budget-safe plan.', true);
        return;
    }

    updateDashboardFromPayload(data);
    showMessage(data.message || 'Budget-safe plan applied.');
}

async function useRemainingBudget() {
    const selected = [...document.querySelectorAll('.remaining-budget-choice:checked')].map(cb => cb.value);

    const data = await postJSON('/use-remaining-budget', { selected_indexes: selected });

    if (!data.success) {
        updateDashboardFromPayload(data);
        showMessage(data.error || 'Could not use remaining budget.', true);
        return;
    }

    updateDashboardFromPayload(data);
    showMessage(data.message || 'Remaining budget allocated.');
}

function renderOptionCards(wrapId, data) {
    const wrap = document.getElementById(wrapId);
    wrap.innerHTML = '';

    if (!data.success) {
        wrap.innerHTML = `<div class="option-box over">${data.error || 'No options could be generated.'}</div>`;
        return;
    }

    const grid = document.createElement('div');
    grid.className = 'options-grid';

    data.options.forEach(opt => {
        const reductionsHtml = (opt.reductions || []).map(r => `
            <div class="reduction-item">
                Reduce <strong>${r.appliance}</strong> by
                <strong>${r.reduced_by} / ${r.current_allocation}</strong>
                ${plural(r.unit_label, r.current_allocation)}
                <br>
                <span class="muted">Remaining after: ${r.remaining_after} ${plural(r.unit_label, r.remaining_after)}</span>
            </div>
        `).join('') || '<div class="reduction-item">No reduction needed.</div>';

        const card = document.createElement('div');
        card.className = 'option-card';
        card.innerHTML = `
            <div class="option-title">${opt.title}</div>
            <div class="option-subtitle">${opt.subtitle}</div>
            <div class="option-subtitle"><strong>Trade-off:</strong> ${opt.reduction_summary}</div>
            ${reductionsHtml}
            <div class="action-row">
                <button class="btn btn-primary">Apply This Option</button>
            </div>
        `;

        card.querySelector('button').addEventListener('click', function() { withSpinner(this, () => applyOption(opt)); });
        grid.appendChild(card);
    });

    wrap.appendChild(grid);
}

async function generatePreferenceOptions() {
    const appliance = document.getElementById('preferred_appliance').value;
    const extra = Number(document.getElementById('preferred_extra').value);

    if (!appliance || extra <= 0) {
        showMessage('Select an appliance and enter extra uses.', true);
        return;
    }

    // Do NOT block based on Uses Wanted or current allocation here.
    // The backend checks the real hard limit: billing period days.
    // This lets an appliance with 1 original use request more usage up to the billing-period cap.
    const data = await postJSON('/generate-preference-options', {
        preferred_appliance: appliance,
        preferred_extra: extra
    });

    renderOptionCards('preference-options-wrap', data);
}


// ── Transfer: Multi-source / Multi-target ─────────────────────────────────
function applianceSelectHtml(excludeNames = []) {
    let html = '<option value="">-- Select --</option>';
    if (currentOptimized && currentOptimized.status === 'Success') {
        currentOptimized.optimized_plan.forEach(item => {
            if (!excludeNames.includes(item.name)) {
                html += `<option value="${item.name}">${item.name}</option>`;
            }
        });
    }
    return html;
}

function addTransferSource() {
    const list = document.getElementById('transfer-sources-list');
    const div = document.createElement('div');
    div.className = 'transfer-row';
    div.innerHTML = `
        <select class="transfer-source-select">${applianceSelectHtml()}</select>
        <div style="display:flex;align-items:center;gap:4px;">
            <input type="number" class="transfer-source-uses" min="1" value="1" style="width:70px;padding:7px;font-size:13px;border-radius:8px;border:1px solid #334155;background:var(--input-bg);color:var(--text);">
            <span class="muted" style="font-size:12px;">uses</span>
        </div>
        <button type="button" class="btn btn-danger" style="padding:6px 10px;" onclick="this.closest('.transfer-row').remove()">✕</button>
    `;
    list.appendChild(div);
}

function addTransferTarget() {
    const list = document.getElementById('transfer-targets-list');
    const div = document.createElement('div');
    div.className = 'transfer-target-row';
    div.innerHTML = `
        <select class="transfer-target-select">${applianceSelectHtml()}</select>
        <button type="button" class="btn btn-danger" style="padding:6px 10px;" onclick="this.closest('.transfer-target-row').remove()">✕</button>
    `;
    list.appendChild(div);
}

function refreshTransferSelects(optimized) {
    document.querySelectorAll('.transfer-source-select, .transfer-target-select').forEach(sel => {
        const old = sel.value;
        sel.innerHTML = applianceSelectHtml();
        if ([...sel.options].some(o => o.value === old)) sel.value = old;
    });
}

async function generateTransferOptions() {
    const sourceRows = [...document.querySelectorAll('#transfer-sources-list .transfer-row')];
    const targetRows = [...document.querySelectorAll('#transfer-targets-list .transfer-target-row')];

    const fromAppliances = [];
    const releasedUsesList = [];
    for (const row of sourceRows) {
        const name = row.querySelector('.transfer-source-select').value;
        const uses = parseInt(row.querySelector('.transfer-source-uses').value);
        if (!name) { showMessage('Select a source appliance for each source row.', true); return; }
        if (!uses || uses <= 0) { showMessage('Enter valid released uses for each source.', true); return; }
        fromAppliances.push(name);
        releasedUsesList.push(uses);
    }

    const toAppliances = [];
    for (const row of targetRows) {
        const name = row.querySelector('.transfer-target-select').value;
        if (!name) { showMessage('Select a target appliance for each target row.', true); return; }
        toAppliances.push(name);
    }

    if (fromAppliances.length === 0) { showMessage('Add at least one source appliance.', true); return; }
    if (toAppliances.length === 0) { showMessage('Add at least one target appliance.', true); return; }

    const data = await postJSON('/generate-transfer-options', {
        from_appliances: fromAppliances,
        released_uses_list: releasedUsesList,
        to_appliances: toAppliances,
    });

    renderOptionCards('transfer-options-wrap', data);
}
// ─────────────────────────────────────────────────────────────────────────

async function applyOption(option) {
    const data = await postJSON('/apply-option', { option });

    if (!data.success) {
        updateDashboardFromPayload(data);
        showMessage(data.error || 'Could not apply option.', true);
        return;
    }

    updateDashboardFromPayload(data);
    clearOptionPanels();
    showMessage(data.message || 'Option applied.');
}

function clearOptionPanels() {
    ['preference-options-wrap', 'transfer-options-wrap', 'whatif-result-wrap'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = '';
    });
}

// ── What If Table ─────────────────────────────────────────────────────────
let whatIfScenario = { modify: [], add: [], remove: [] };

function initWhatIfTable(optimized) {
    const tbody = document.getElementById('whatif-appliance-body');
    if (!tbody || !optimized || optimized.status !== 'Success') return;
    tbody.innerHTML = '';
    whatIfScenario = { modify: [], add: [], remove: [] };
    document.getElementById('whatif-result-wrap').innerHTML = '';
    document.getElementById('whatif-apply-row').style.display = 'none';

    const appLookup = {};
    (currentAppliances || []).forEach(a => { appLookup[a.name] = a; });

    optimized.optimized_plan.forEach(item => {
        const full = appLookup[item.name] || {};
        addWhatIfExistingRow(Object.assign({}, full, item));
    });
}

function prioritySelectHtmlWi(value) {
    const opts = [[10,'Critical'],[9,'Very Important'],[8,'Important'],
        [7,'Regular Use'],[6,'Moderate'],[5,'Neutral'],
        [4,'Flexible'],[3,'Low Priority'],[2,'Rarely Needed'],[1,'Optional']];
    return '<select class="wi-priority" style="padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:12px;">' +
        opts.map(([v,l]) => `<option value="${v}"${v===value?' selected':''}>${l}</option>`).join('') +
        '</select>';
}

function addWhatIfExistingRow(item) {
    const tbody = document.getElementById('whatif-appliance-body');
    const tr = document.createElement('tr');
    tr.dataset.name = item.name;
    tr.dataset.isNew = 'false';
    tr.innerHTML = `
        <td style="font-weight:500;">${item.name}</td>
        <td><input type="number" class="wi-uses" min="0" max="${getDays()}" value="${item.desired_uses}" style="width:75px;padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;"></td>
        <td><input type="number" class="wi-hours" min="0.1" max="24" step="0.1" value="${item.hours_per_use || ''}" placeholder="auto" style="width:70px;padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;"></td>
        <td>${prioritySelectHtmlWi(item.priority)}</td>
        <td><span class="chip" style="font-size:11px;">Existing</span></td>
        <td><button type="button" class="btn btn-danger" style="padding:4px 9px;font-size:12px;" onclick="removeWhatIfRow(this)">Remove</button></td>
    `;
    tbody.appendChild(tr);
}

function addWhatIfRow() {
    const tbody = document.getElementById('whatif-appliance-body');
    const tr = document.createElement('tr');
    tr.dataset.isNew = 'true';
    tr.className = 'whatif-new';

    let selectHtml = '<option value="">-- Select or type --</option>';
    for (const [n, info] of Object.entries(applianceDefaults)) {
        selectHtml += `<option value="${n}" data-watts="${info.watts}" data-priority="${info.priority||5}" data-hours="${info.hours_per_use||''}" data-uses="${info.default_desired_uses||1}">${n}</option>`;
    }
    selectHtml += '<option value="__custom__">Custom...</option>';

    tr.innerHTML = `
        <td>
            <select class="wi-name-select" onchange="handleWiSelect(this)" style="padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;">${selectHtml}</select>
            <input type="text" class="wi-custom-name" placeholder="Name" style="display:none;margin-top:4px;padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;width:100%;">
            <input type="hidden" class="wi-name-val" value="">
            <input type="number" class="wi-watts" placeholder="Watts" min="1" max="10000" style="display:none;margin-top:4px;padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;width:80px;">
        </td>
        <td><input type="number" class="wi-uses" min="0" max="${getDays()}" value="1" style="width:75px;padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;"></td>
        <td><input type="number" class="wi-hours" min="0.1" max="24" step="0.1" placeholder="auto" style="width:70px;padding:5px 7px;border-radius:7px;border:1px solid #334155;background:var(--input-bg);color:var(--text);font-size:13px;"></td>
        <td>${prioritySelectHtmlWi(5)}</td>
        <td><span class="chip" style="font-size:11px;background:#064e3b;color:#6ee7b7;">New</span></td>
        <td><button type="button" class="btn btn-danger" style="padding:4px 9px;font-size:12px;" onclick="this.closest('tr').remove()">Remove</button></td>
    `;
    tbody.appendChild(tr);
}

function handleWiSelect(sel) {
    const tr = sel.closest('tr');
    const custom = tr.querySelector('.wi-custom-name');
    const nameVal = tr.querySelector('.wi-name-val');
    const wattsInput = tr.querySelector('.wi-watts');
    if (sel.value === '__custom__') {
        custom.style.display = 'block';
        wattsInput.style.display = 'block';
        nameVal.value = '';
    } else if (sel.value === '') {
        custom.style.display = 'none';
        wattsInput.style.display = 'none';
        nameVal.value = '';
    } else {
        custom.style.display = 'none';
        wattsInput.style.display = 'none';
        nameVal.value = sel.value;
        const opt = sel.selectedOptions[0];
        if (opt.dataset.watts) { wattsInput.value = opt.dataset.watts; }
        if (opt.dataset.hours) { tr.querySelector('.wi-hours').value = opt.dataset.hours; }
        if (opt.dataset.uses) { tr.querySelector('.wi-uses').value = opt.dataset.uses; }
        const priSel = tr.querySelector('.wi-priority');
        if (opt.dataset.priority) priSel.value = opt.dataset.priority;
    }
}

function removeWhatIfRow(btn) {
    btn.closest('tr').remove();
}

function buildWhatIfScenario() {
    const rows = [...document.querySelectorAll('#whatif-appliance-body tr')];
    const modify = [], add = [], remove = [];

    const presentNames = new Set(
        rows.filter(tr => tr.dataset.isNew === 'false').map(tr => tr.dataset.name)
    );
    (currentAppliances || []).forEach(a => {
        if (!presentNames.has(a.name)) remove.push(a.name);
    });

    rows.filter(tr => tr.dataset.isNew === 'false').forEach(tr => {
        modify.push({
            name: tr.dataset.name,
            desired_uses: parseInt(tr.querySelector('.wi-uses').value) || 0,
            hours_per_use: parseFloat(tr.querySelector('.wi-hours').value) || undefined,
            priority: parseInt(tr.querySelector('.wi-priority').value) || 5,
        });
    });

    rows.filter(tr => tr.dataset.isNew === 'true').forEach(tr => {
        const nameVal = tr.querySelector('.wi-name-val').value.trim()
            || tr.querySelector('.wi-custom-name').value.trim();
        if (!nameVal) return;
        const watts = parseFloat(tr.querySelector('.wi-watts').value) || (applianceDefaults[nameVal] ? applianceDefaults[nameVal].watts : 100);
        add.push({
            name: nameVal,
            watts,
            desired_uses: parseInt(tr.querySelector('.wi-uses').value) || 1,
            hours_per_use: parseFloat(tr.querySelector('.wi-hours').value) || undefined,
            priority: parseInt(tr.querySelector('.wi-priority').value) || 5,
            unit_label: (applianceDefaults[nameVal] || {}).unit_label || 'use',
        });
    });

    return { modify, add, remove };
}

async function runWhatIf() {
    const scenario = buildWhatIfScenario();
    const wrap = document.getElementById('whatif-result-wrap');
    const applyRow = document.getElementById('whatif-apply-row');

    const data = await postJSON('/what-if', scenario);

    if (!data.success) {
        wrap.innerHTML = `<div class="option-box over">${data.error || 'What-if failed.'}</div>`;
        applyRow.style.display = 'none';
        return;
    }

    const result = data.result;
    const priLabel = p => priorityLabels[p] || `${p}/10`;
    const priDesc = p => priorityDescriptions[p] || '';

    let html = `
        <div class="option-box">
            <strong>Preview only — not saved yet</strong>
            <div class="muted" style="margin-bottom:10px;">Total: ${money(result.total_cost)} &nbsp;•&nbsp; Remaining: ${money(result.budget_remaining)}</div>
            <div style="overflow-x:auto;">
            <table>
                <thead><tr>
                    <th>Appliance</th><th>Priority</th><th>Uses Wanted (Days/Month)</th>
                    <th>Would Allocate</th><th>Cost</th>
                </tr></thead>
                <tbody>
    `;

    result.optimized_plan.forEach(item => {
        const label = priLabel(item.priority);
        const desc = priDesc(item.priority);
        html += `
            <tr>
                <td>${item.name}</td>
                <td><span class="priority-badge">${label}<span class="priority-tooltip">${desc}</span></span></td>
                <td>${item.desired_uses} ${plural(item.unit_label, item.desired_uses)}</td>
                <td><span class="chip">${item.allowed_uses} ${plural(item.unit_label, item.allowed_uses)}</span></td>
                <td>${money(item.cost)}</td>
            </tr>
        `;
    });

    html += `</tbody></table></div></div>`;
    wrap.innerHTML = html;
    applyRow.style.display = 'flex';
}

async function applyWhatIf() {
    const scenario = buildWhatIfScenario();
    const data = await postJSON('/apply-what-if', scenario);

    if (!data.success) {
        showMessage(data.error || 'Could not apply changes.', true);
        return;
    }

    if (data.user_appliances) {
        currentAppliances = data.user_appliances;
        rebuildAppliancePage(currentAppliances);
    }
    updateDashboardFromPayload(data);
    showMessage(data.message || 'Changes applied.');
    document.getElementById('whatif-apply-row').style.display = 'none';
    document.getElementById('whatif-result-wrap').innerHTML = '';
    switchView('dashboard');
}

function rebuildAppliancePage(appliances) {
    const list = document.getElementById('appliance-list');
    if (!list) return;
    list.innerHTML = '';
    appliances.forEach(app => {
        const isCustom = !applianceDefaults[app.name];
        let selectHtml = '<option value="">-- Select --</option>';
        for (const [name, info] of Object.entries(applianceDefaults)) {
            selectHtml += `<option value="${name}" data-watts="${info.watts}" data-priority="${info.priority||5}" data-hours="${info.hours_per_use||''}"${app.name === name ? ' selected' : ''}>${name}</option>`;
        }
        selectHtml += `<option value="__custom__"${isCustom ? ' selected' : ''}>Custom</option>`;

        const priOpts = [
            [10,'Critical','Cannot realistically reduce this appliance.'],
            [9,'Very Important','Strongly protected from reductions.'],
            [8,'Important','Prefer to keep this appliance active.'],
            [7,'Regular Use','Used often in normal daily life.'],
            [6,'Moderate','Useful but somewhat flexible.'],
            [5,'Neutral','Average importance appliance.'],
            [4,'Flexible','Can be reduced if necessary.'],
            [3,'Low Priority','One of the first appliances reduced.'],
            [2,'Rarely Needed','Only occasionally needed.'],
            [1,'Optional','Only used if budget allows.'],
        ];
        const priHtml = priOpts.map(([v,l,d]) =>
            `<option value="${v}" title="${d}"${app.priority == v ? ' selected' : ''}>${l}</option>`
        ).join('');

        const days = parseInt(document.getElementById('fin-days').value) || 30;

        list.insertAdjacentHTML('beforeend', `
            <div class="appliance-row">
                <div>
                    <label class="muted">Appliance</label>
                    <input type="hidden" name="appliance_name" class="appliance-name-value" value="${app.name}">
                    <select class="appliance-select" onchange="handleApplianceSelect(this)">${selectHtml}</select>
                    <input type="text" class="custom-name-input" placeholder="Appliance name"
                           value="${isCustom ? app.name : ''}"
                           style="display:${isCustom ? 'block' : 'none'}; margin-top:6px;"
                           oninput="syncCustomName(this)">
                </div>
                <div>
                    <label class="muted">Watts</label>
                    <input name="appliance_watts" value="${app.watts}" type="number" placeholder="e.g. 200" min="1" max="10000" oninput="validateField(this, 1, 10000, 'Max 10,000W')">
                    <div class="field-error">Max 10,000W</div>
                </div>
                <div>
                    <label class="muted">Uses Wanted (Days/Month)</label>
                    <input name="appliance_desired_uses" value="${app.desired_uses}" type="number" min="0" max="${days}" placeholder="0 = auto" oninput="validateField(this, 0, ${days}, 'Max ${days} uses')">
                    <div class="field-error">Max ${days} uses</div>
                </div>
                <div>
                    <label class="muted">Hrs/Use</label>
                    <input name="appliance_hours_per_use" value="${app.hours_per_use || ''}" type="number" min="0.1" max="24" step="0.1" placeholder="auto" oninput="validateField(this, 0.1, 24, 'Hours between 0.1 and 24')">
                    <div class="field-error">Hours between 0.1 and 24</div>
                </div>
                <div>
                    <label class="muted">Priority <span style="font-size:11px;cursor:help;" title="Priority determines allocation preference.">ⓘ</span></label>
                    <select name="appliance_priority" onchange="updatePriorityMeaning(this)">
                        ${priHtml}
                    </select>
                    <div class="priority-help muted" style="font-size:12px; margin-top:5px;"></div>
                </div>
                <button type="button" class="btn btn-danger" onclick="this.closest('.appliance-row').remove()">X</button>
            </div>
        `);
    });
    list.querySelectorAll('select[name="appliance_priority"]').forEach(updatePriorityMeaning);
}
// ─────────────────────────────────────────────────────────────────────────

// ── Field validation ──────────────────────────────────────────────────────
function validateField(input, min, max, msg) {
    const val = Number(input.value);
    const err = input.nextElementSibling;
    const invalid = input.value !== '' && (val < min || val > max);
    input.classList.toggle('input-invalid', invalid);
    if (err && err.classList.contains('field-error')) {
        err.style.display = invalid ? 'block' : 'none';
    }
}

function formHasErrors() {
    return [...document.querySelectorAll('.input-invalid')].length > 0;
}
// ─────────────────────────────────────────────────────────────────────────

// ── Budget Chart ──────────────────────────────────────────────────────────
const CHART_COLORS = [
    '#6366f1','#10b981','#f59e0b','#f87171','#38bdf8',
    '#a78bfa','#34d399','#fb923c','#e879f9','#4ade80'
];

let budgetChart = null;
let currentChartType = 'doughnut';

function buildChartData(optimized) {
    if (!optimized || optimized.status !== 'Success') return null;
    const labels = optimized.optimized_plan.map(i => i.name);
    const values = optimized.optimized_plan.map(i => i.cost);
    return { labels, values };
}

function renderChart(optimized, type) {
    const canvas = document.getElementById('budget-chart');
    if (!canvas) return;

    const chartData = buildChartData(optimized);
    if (!chartData) return;

    if (budgetChart) {
        budgetChart.destroy();
        budgetChart = null;
    }

    const isDoughnut = type === 'doughnut';

    budgetChart = new Chart(canvas, {
        type: isDoughnut ? 'doughnut' : 'bar',
        data: {
            labels: chartData.labels,
            datasets: [{
                data: chartData.values,
                backgroundColor: CHART_COLORS.slice(0, chartData.labels.length),
                borderWidth: isDoughnut ? 2 : 0,
                borderColor: '#0f172a',
                borderRadius: isDoughnut ? 0 : 6,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: isDoughnut,
                    position: 'bottom',
                    labels: { color: '#94a3b8', padding: 16, font: { size: 13 } }
                },
                tooltip: {
                    callbacks: {
                        label: ctx => ` $${Number(ctx.raw).toFixed(2)}`
                    }
                }
            },
            scales: isDoughnut ? {} : {
                x: { ticks: { color: '#94a3b8' }, grid: { color: '#1f2937' } },
                y: {
                    ticks: {
                        color: '#94a3b8',
                        callback: v => '$' + v.toFixed(2)
                    },
                    grid: { color: '#1f2937' }
                }
            }
        }
    });
}

function switchChart(type) {
    currentChartType = type;
    document.getElementById('chart-btn-doughnut').classList.toggle('active', type === 'doughnut');
    document.getElementById('chart-btn-bar').classList.toggle('active', type === 'bar');
    renderChart(currentOptimized, type);
}
// ─────────────────────────────────────────────────────────────────────────

// ── Cost Alerts ───────────────────────────────────────────────────────────
function renderCostAlerts(optimized) {
    const wrap = document.getElementById('cost-alerts-wrap');
    if (!wrap || !optimized || optimized.status !== 'Success') return;

    const plan = optimized.optimized_plan;
    const totalCost = optimized.total_cost || 0;
    wrap.innerHTML = '';

    if (totalCost <= 0) return;

    plan.forEach(item => {
        const pct = (item.cost / totalCost) * 100;

        let level, icon, headline, detail;

        if (pct >= 50) {
            level = 'high'; icon = '🔴';
            headline = `${item.name} uses ${pct.toFixed(0)}% of your allocated budget`;
            detail = `At $${item.cost.toFixed(2)}, this single appliance dominates your plan. Consider reducing its usage or priority.`;
        } else if (pct >= 30) {
            level = 'high'; icon = '🟠';
            headline = `${item.name} takes up ${pct.toFixed(0)}% of your allocated budget`;
            detail = `That's $${item.cost.toFixed(2)} out of $${totalCost.toFixed(2)} total. Worth reviewing if you're tight on budget.`;
        } else if (pct >= 20) {
            level = 'med'; icon = '🟡';
            headline = `${item.name} accounts for ${pct.toFixed(0)}% of your allocated budget`;
            detail = `Costing $${item.cost.toFixed(2)}. Moderate impact — keep an eye on this one.`;
        } else {
            return;
        }

        wrap.insertAdjacentHTML('beforeend', `
            <div class="alert-item alert-${level}">
                <span class="alert-icon">${icon}</span>
                <div class="alert-text">
                    <strong>${headline}</strong>
                    ${detail}
                </div>
            </div>
        `);
    });
}
// ─────────────────────────────────────────────────────────────────────────

// ── Dark / Light Mode ─────────────────────────────────────────────────────
function applyTheme(theme) {
    document.body.classList.toggle('light', theme === 'light');
    const btn = document.getElementById('theme-toggle');
    if (btn) btn.textContent = theme === 'light' ? '🌙' : '☀️';
}

function toggleTheme() {
    const isLight = document.body.classList.contains('light');
    const next = isLight ? 'dark' : 'light';
    localStorage.setItem('energyTheme', next);
    applyTheme(next);
}
// ─────────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
    applyTheme(localStorage.getItem('energyTheme') || 'dark');

    initOnboarding();
    document.querySelectorAll('select[name="appliance_priority"]').forEach(updatePriorityMeaning);

    if (currentOptimized && currentOptimized.status === 'Success') {
        renderOptimizedPlan(currentOptimized);
        populateDashboardSelects(currentOptimized);
        renderRemainingBudgetCheckboxes(currentOptimized);
        renderUsageSummary(window.INITIAL_USAGE_SUMMARY || []);
        renderChart(currentOptimized, currentChartType);
        renderCostAlerts(currentOptimized);
        initWhatIfTable(currentOptimized);
        addTransferSource();
        addTransferTarget();
    }
});

// ── Onboarding Stepper ───────────────────────────────────────────
const HAS_PLAN = !!(currentOptimized && currentOptimized.status === 'Success');

function initOnboarding() {
    if (!HAS_PLAN) {
        document.getElementById('onboarding-overlay').classList.remove('hidden');
        addObRow();
    }
}

function dismissOnboarding() {
    document.getElementById('onboarding-overlay').classList.add('hidden');
}

function stepperGo(step) {
    [1,2,3].forEach(i => {
        document.getElementById('pane-' + i).classList.toggle('active', i === step);
        const ind = document.getElementById('ind-' + i);
        ind.classList.remove('active', 'done');
        if (i < step) ind.classList.add('done');
        if (i === step) ind.classList.add('active');
    });
    [1,2,3].forEach(i => {
        const circle = document.querySelector('#ind-' + i + ' .step-circle');
        if (i < step) circle.textContent = '✓';
        else circle.textContent = i;
    });
}

function stepperNext1() {
    const budget = parseFloat(document.getElementById('ob-budget').value);
    if (!budget || budget <= 0) {
        document.getElementById('ob-budget').focus();
        document.getElementById('ob-budget').style.borderColor = '#f87171';
        return;
    }
    document.getElementById('ob-budget').style.borderColor = '';
    stepperGo(2);
}

function stepperNext2() {
    const rows = document.querySelectorAll('#ob-appliance-list .ob-row');
    const valid = [...rows].some(r => r.querySelector('.ob-name-val').value.trim());
    const errEl = document.getElementById('ob-appliance-error');
    if (!valid) { errEl.style.display = 'block'; return; }
    errEl.style.display = 'none';
    buildObSummary();
    stepperGo(3);
}

function obPrioritySelect(val) {
    const opts = [
        [10,'Critical','Cannot realistically reduce this appliance.'],
        [9,'Very Important','Strongly protected from reductions.'],
        [8,'Important','Prefer to keep this appliance active.'],
        [7,'Regular Use','Used often in normal daily life.'],
        [6,'Moderate','Useful but somewhat flexible.'],
        [5,'Neutral','Average importance appliance.'],
        [4,'Flexible','Can be reduced if necessary.'],
        [3,'Low Priority','One of the first appliances reduced.'],
        [2,'Rarely Needed','Only occasionally needed.'],
        [1,'Optional','Only used if budget allows.'],
    ];
    return '<select class="ob-priority">' +
        opts.map(([v,l,d]) => `<option value="${v}" title="${d}"${v===(val||5)?' selected':''}>${l}</option>`).join('') +
    '</select>';
}

function addObRow(name='', watts='', uses='', priority=5, hours='') {
    const list = document.getElementById('ob-appliance-list');
    const div = document.createElement('div');
    div.className = 'ob-row';
    div.style.cssText = 'display:grid;grid-template-columns:1.4fr .9fr .9fr .9fr .9fr 36px;gap:8px;align-items:end;margin-bottom:10px;';

    let selectHtml = '<option value="">-- Select --</option>';
    for (const [n, info] of Object.entries(applianceDefaults)) {
        selectHtml += `<option value="${n}" data-watts="${info.watts}" data-priority="${info.priority||5}" data-hours="${info.hours_per_use||''}"${n===name?' selected':''}>${n}</option>`;
    }
    selectHtml += '<option value="__custom__">Custom...</option>';

    div.innerHTML = `
        <div>
            <label style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px;">Appliance</label>
            <input type="hidden" class="ob-name-val" value="${name}">
            <select class="ob-select" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:white;font-size:13px;" onchange="handleObSelect(this)">
                ${selectHtml}
            </select>
            <input type="text" class="ob-custom" placeholder="Appliance name" style="display:none;margin-top:5px;width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:white;font-size:13px;" oninput="this.closest('.ob-row').querySelector('.ob-name-val').value=this.value">
        </div>
        <div>
            <label style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px;">Watts</label>
            <input type="number" class="ob-watts" value="${watts}" placeholder="e.g. 200" min="1" max="10000" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:white;font-size:13px;">
        </div>
        <div>
            <label style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px;">Uses/Month</label>
            <input type="number" class="ob-uses" value="${uses}" placeholder="e.g. 20" min="0" max="365" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:white;font-size:13px;">
        </div>
        <div>
            <label style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px;">Hrs/Use</label>
            <input type="number" class="ob-hours" value="${hours}" placeholder="auto" min="0.1" max="24" step="0.1" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:white;font-size:13px;" title="Leave blank to use the default hours for this appliance">
        </div>
        <div>
            <label style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px;">Priority</label>
            ${obPrioritySelect(priority)}
        </div>
        <button type="button" style="padding:10px 8px;border:none;border-radius:8px;background:#7f1d1d;color:white;cursor:pointer;font-weight:bold;" onclick="this.closest('.ob-row').remove()">✕</button>
    `;

    div.querySelector('.ob-priority').style.cssText = 'width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:white;font-size:13px;';
    list.appendChild(div);
}

function handleObSelect(sel) {
    const row = sel.closest('.ob-row');
    const custom = row.querySelector('.ob-custom');
    const nameVal = row.querySelector('.ob-name-val');
    const wattsInput = row.querySelector('.ob-watts');
    if (sel.value === '__custom__') {
        custom.style.display = 'block';
        nameVal.value = '';
    } else if (sel.value === '') {
        custom.style.display = 'none';
        nameVal.value = '';
    } else {
        custom.style.display = 'none';
        nameVal.value = sel.value;
        const opt = sel.selectedOptions[0];
        if (opt.dataset.watts) wattsInput.value = opt.dataset.watts;
        const priSel = row.querySelector('.ob-priority');
        if (opt.dataset.priority) priSel.value = opt.dataset.priority;
        const hoursSel = row.querySelector('.ob-hours');
        if (opt.dataset.hours) hoursSel.value = opt.dataset.hours;
        else hoursSel.value = '';
    }
}

function buildObSummary() {
    const budget = parseFloat(document.getElementById('ob-budget').value) || 0;
    const rate   = parseFloat(document.getElementById('ob-rate').value) || 45.46;
    const days   = parseInt(document.getElementById('ob-days').value) || 30;
    const rows   = [...document.querySelectorAll('#ob-appliance-list .ob-row')];

    let appHtml = rows
        .filter(r => r.querySelector('.ob-name-val').value.trim())
        .map(r => {
            const name  = r.querySelector('.ob-name-val').value;
            const uses  = r.querySelector('.ob-uses').value || 'auto';
            const pri   = r.querySelector('.ob-priority').options[r.querySelector('.ob-priority').selectedIndex].text;
            return `<tr>
                <td style="padding:7px 8px;border-bottom:1px solid #1f2937;">${name}</td>
                <td style="padding:7px 8px;border-bottom:1px solid #1f2937;color:#94a3b8;">${uses} uses</td>
                <td style="padding:7px 8px;border-bottom:1px solid #1f2937;color:#94a3b8;">${pri}</td>
            </tr>`;
        }).join('');

    document.getElementById('ob-summary').innerHTML = `
        <div style="background:#0f172a;border-radius:12px;padding:14px;margin-bottom:12px;">
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;text-align:center;">
                <div><div style="color:#64748b;font-size:11px;text-transform:uppercase;">Budget</div><div style="font-size:20px;font-weight:bold;color:#10b981;">$${budget.toFixed(2)}</div></div>
                <div><div style="color:#64748b;font-size:11px;text-transform:uppercase;">Rate</div><div style="font-size:20px;font-weight:bold;">$${rate}</div></div>
                <div><div style="color:#64748b;font-size:11px;text-transform:uppercase;">Days</div><div style="font-size:20px;font-weight:bold;">${days}</div></div>
            </div>
        </div>
        <table style="width:100%;border-collapse:collapse;">
            <thead><tr>
                <th style="padding:7px 8px;text-align:left;color:#64748b;font-size:11px;text-transform:uppercase;">Appliance</th>
                <th style="padding:7px 8px;text-align:left;color:#64748b;font-size:11px;text-transform:uppercase;">Uses</th>
                <th style="padding:7px 8px;text-align:left;color:#64748b;font-size:11px;text-transform:uppercase;">Priority</th>
            </tr></thead>
            <tbody>${appHtml}</tbody>
        </table>
    `;
}

async function submitObForm() {
    const budget = document.getElementById('ob-budget').value || 0;
    const rate   = document.getElementById('ob-rate').value || 45.46;
    const days   = document.getElementById('ob-days').value || 30;

    document.getElementById('hidden-budget').value = budget;
    document.getElementById('hidden-rate').value   = rate;
    document.getElementById('hidden-days').value   = days;

    document.getElementById('appliance-list').innerHTML = '';

    const rows = [...document.querySelectorAll('#ob-appliance-list .ob-row')];
    rows.forEach(r => {
        const name  = r.querySelector('.ob-name-val').value.trim();
        if (!name) return;
        const watts = r.querySelector('.ob-watts').value || 0;
        const uses  = r.querySelector('.ob-uses').value || 0;
        const hours = r.querySelector('.ob-hours').value || '';
        const qty   = 1;
        const pri   = r.querySelector('.ob-priority').value || 5;

        const hidden = `
            <div class="appliance-row" style="display:none;">
                <input type="hidden" name="appliance_name"         class="appliance-name-value" value="${name}">
                <input type="hidden" name="appliance_watts"         value="${watts}">
                <input type="hidden" name="appliance_desired_uses"  value="${uses}">
                <input type="hidden" name="appliance_quantity"      value="${qty}">
                <input type="hidden" name="appliance_priority"      value="${pri}">
                <input type="hidden" name="appliance_hours_per_use" value="${hours}">
            </div>`;
        document.getElementById('appliance-list').insertAdjacentHTML('beforeend', hidden);
    });

    document.getElementById('main-form').submit();
}
// ── End Onboarding Stepper ───────────────────────────────────────

// ── Dynamic Tracking ────────────────────────────────────────────────────────
async function applyAllLogs() {
    const inputs = [...document.querySelectorAll('.log-uses-input')];
    const toLog = inputs
        .map(inp => ({ name: inp.dataset.appliance, uses: parseInt(inp.value) || 0 }))
        .filter(item => item.uses > 0);

    if (toLog.length === 0) {
        showMessage('No uses entered. Set at least one appliance to > 0 before applying logs.', true);
        return;
    }

    let lastData = null;
    for (const item of toLog) {
        lastData = await postJSON('/log-consumption', { appliance: item.name, uses: item.uses });
    }

    if (lastData) {
        updateDashboardFromPayload(lastData);
        document.querySelectorAll('.log-uses-input').forEach(inp => inp.value = 0);
        if (lastData.overrun) {
            showMessage(
                `⚠️ Budget exceeded by J$${parseFloat(lastData.overspend).toFixed(2)}. ` +
                `All remaining allocations set to zero.`, true
            );
        } else {
            showMessage(`✅ Logs applied. Remaining budget re-optimized.`);
        }
    }
}

async function logConsumption(applianceName, uses) {
    const usesInt = parseInt(uses);
    if (!applianceName || isNaN(usesInt) || usesInt <= 0) {
        showMessage('Enter a valid number of uses to log.', true);
        return;
    }

    const data = await postJSON('/log-consumption', {
        appliance: applianceName,
        uses: usesInt
    });

    if (!data.success) {
        showMessage(data.error || 'Could not log consumption.', true);
        return;
    }

    updateDashboardFromPayload(data);

    if (data.overrun) {
        showMessage(
            `⚠️ Budget exceeded by J$${data.overspend.toFixed(2)}. ` +
            `All remaining allocations have been set to zero. ` +
            `Consider starting a new billing period or adjusting your budget.`,
            true
        );
    } else {
        showMessage(
            `✅ Logged ${usesInt} use(s) of ${applianceName}. ` +
            `Remaining appliances re-optimized around updated budget.`
        );
    }
}

async function resetPeriod() {
    if (!confirm('Start a new billing period? This will clear all logged consumption and re-optimize your full budget.')) return;

    const data = await postJSON('/reset-period');

    if (!data.success) {
        showMessage(data.error || 'Could not reset period.', true);
        return;
    }

    updateDashboardFromPayload(data);
    showMessage('🔄 New billing period started. All consumption cleared and plan re-optimized.');

    const periodEl = document.querySelector('.muted[style*="Period started"]');
    if (periodEl) {
        const today = new Date().toISOString().split('T')[0];
        periodEl.textContent = 'Period started: ' + today;
    }
}
// ── End Dynamic Tracking ────────────────────────────────────────────────────