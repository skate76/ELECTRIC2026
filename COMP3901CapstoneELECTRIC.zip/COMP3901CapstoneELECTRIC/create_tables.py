"""
Run this once to create any missing tables (including appliance_catalog).
Safe to run multiple times — it won't touch tables that already exist.

Usage:
    python create_tables.py
"""
from db import engine, Base
import models  # must import so all models are registered with Base

Base.metadata.create_all(bind=engine)
print("Done — all tables created (existing ones untouched).")