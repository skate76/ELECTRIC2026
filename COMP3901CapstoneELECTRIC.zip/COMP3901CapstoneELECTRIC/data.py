users = {}

FIXED_RATE = 45.46

default_appliances = {
    "Refrigerator": {
        "watts": 200,
        "priority": 10,
        "usage_mode": "day_based",
        "hours_per_use": 24,
        "unit_label": "day",
        "default_desired_uses": 30
    },
    "Air Conditioner": {
        "watts": 1500,
        "priority": 8,
        "usage_mode": "session_based",
        "hours_per_use": 8,
        "unit_label": "night",
        "default_desired_uses": 8
    },
    "Gaming PC": {
        "watts": 600,
        "priority": 4,
        "usage_mode": "session_based",
        "hours_per_use": 3,
        "unit_label": "session",
        "default_desired_uses": 10
    },
    "LED Bulb": {
        "watts": 15,
        "priority": 7,
        "usage_mode": "day_based",
        "hours_per_use": 5,
        "unit_label": "day",
        "default_desired_uses": 20
    },
    "Router": {
        "watts": 12,
        "priority": 9,
        "usage_mode": "day_based",
        "hours_per_use": 24,
        "unit_label": "day",
        "default_desired_uses": 30
    },
    "Washing Machine": {
        "watts": 500,
        "priority": 3,
        "usage_mode": "session_based",
        "hours_per_use": 1.5,
        "unit_label": "wash",
        "default_desired_uses": 6
    }
}
