def cost_per_use(appliance, rate):
    return (
        (float(appliance.get("watts", 0)) / 1000.0)
        * float(appliance.get("hours_per_use", 1))
        * float(rate)
        * int(appliance.get("quantity", 1))
    )


def ensure_desired_defaults(user):
    for app in user.get("appliances", []):
        if int(app.get("desired_uses", 0)) <= 0:
            app["desired_uses"] = int(app.get("default_desired_uses", 1))


def calculate_desired_plan_cost(user):
    total = 0.0
    breakdown = []

    ensure_desired_defaults(user)

    for app in user.get("appliances", []):
        uses = int(app.get("desired_uses", 0))
        cpu = cost_per_use(app, user.get("rate", 45.46))
        cost = uses * cpu
        total += cost

        breakdown.append({
            "name": app["name"],
            "desired_uses": uses,
            "unit_label": app.get("unit_label", "use"),
            "cost_per_use": round(cpu, 2),
            "cost": round(cost, 2),
        })

    budget = float(user.get("budget", 0))
    return {
        "total_cost": round(total, 2),
        "breakdown": breakdown,
        "budget_warning": total > budget,
        "overage": round(max(0, total - budget), 2),
    }
