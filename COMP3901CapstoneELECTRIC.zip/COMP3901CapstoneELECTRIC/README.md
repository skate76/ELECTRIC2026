# Energy Dashboard Live Update Version

## How to run

```bash
python app.py
```

Then open:

```text
http://127.0.0.1:5000
```

Do not open `index.html` directly.

## What changed

- Button clicks now update visible dashboard sections immediately.
- `desired_uses` remains the user's original requested usage.
- `allocated_uses` stores the current budget-safe allocation.
- Flask routes reload fresh saved user data for each button request.
- Apply buttons send the full selected option back to Flask.
- The frontend redraws the allocation table, totals, usage bars, and select options after changes.
