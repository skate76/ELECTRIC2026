"""
Migration: adds dynamic tracking columns needed for mid-period replanning.

New columns:
  appliances.consumed_uses      INTEGER NOT NULL DEFAULT 0
  users.period_start_date       DATE

Safe to run multiple times — skips columns that already exist.

Usage:
    python migrate_dynamic_tracking.py
"""
from db import engine
from sqlalchemy import text

MIGRATIONS = [
    {
        "table": "appliances",
        "column": "consumed_uses",
        "ddl": "ALTER TABLE appliances ADD COLUMN consumed_uses INTEGER NOT NULL DEFAULT 0",
        "description": "tracks actual usage per appliance this billing period",
    },
    {
        "table": "users",
        "column": "period_start_date",
        "ddl": "ALTER TABLE users ADD COLUMN period_start_date DATE",
        "description": "records when the current billing period started",
    },
]

with engine.connect() as conn:
    for m in MIGRATIONS:
        result = conn.execute(text("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = :table AND column_name = :column
        """), {"table": m["table"], "column": m["column"]})

        if result.fetchone():
            print(f"  SKIP  {m['table']}.{m['column']} already exists.")
        else:
            conn.execute(text(m["ddl"]))
            conn.commit()
            print(f"  ADDED {m['table']}.{m['column']} — {m['description']}")

print("\nDone — dynamic tracking migration complete.")