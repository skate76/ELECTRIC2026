from sqlalchemy import Column, Integer, String, Float, JSON, UniqueConstraint, Date
from db import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    user_id = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=True)   #None = account not yet secured
    budget = Column(Float, default=0.0)
    rate = Column(Float, default=45.46)
    days = Column(Integer, default=30)
    initial_optimized_plan = Column(JSON, nullable=True)
    #Dynamic tracking: the date the current billing period started
    period_start_date = Column(Date, nullable=True)


class Appliance(Base):
    __tablename__ = "appliances"

    id = Column(Integer, primary_key=True)
    user_id = Column(String, nullable=False)
    name = Column(String, nullable=False)
    watts = Column(Float, nullable=False)
    hours_per_use = Column(Float, default=1.0)
    quantity = Column(Integer, default=1)
    priority = Column(Integer, default=5)
    usage_mode = Column(String, default="session_based")
    unit_label = Column(String, default="use")
    desired_uses = Column(Integer, default=1)
    allocated_uses = Column(Integer, nullable=True)
    default_desired_uses = Column(Integer, default=1)
    # Dynamic tracking: how many uses have actually occurred this billing period
    consumed_uses = Column(Integer, default=0, nullable=False)


class ApplianceCatalog(Base):
    """Shared catalog — one row per unique appliance name, built from all users."""
    __tablename__ = "appliance_catalog"

    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    watts = Column(Float, nullable=False)
    # These default to session_based/use; overridden when we know more
    hours_per_use = Column(Float, default=1.0)
    usage_mode = Column(String, default="session_based")
    unit_label = Column(String, default="use")
    default_desired_uses = Column(Integer, default=1)